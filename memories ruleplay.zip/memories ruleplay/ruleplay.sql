-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gazdă: 127.0.0.1
-- Timp de generare: iul. 23, 2024 la 08:04 PM
-- Versiune server: 10.4.32-MariaDB
-- Versiune PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `czm`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `actiunipanelbre`
--

CREATE TABLE `actiunipanelbre` (
  `id` int(11) NOT NULL,
  `actionid` int(11) NOT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `complaintid` int(11) NOT NULL DEFAULT 0,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `playername` varchar(64) NOT NULL,
  `givername` varchar(64) NOT NULL,
  `reason` varchar(128) NOT NULL,
  `dm` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `adv`
--

CREATE TABLE `adv` (
  `id` int(11) NOT NULL,
  `word` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `adv`
--

INSERT INTO `adv` (`id`, `word`) VALUES
(1, 'bzone'),
(2, 'bugged'),
(3, 'lupmax'),
(4, 'b-zone'),
(5, 'og-times'),
(6, 'ogtimes'),
(7, 'b-game'),
(8, 'gfzone'),
(9, 'famzone'),
(10, 't4p'),
(11, 'time4play'),
(12, 'pro-gaming'),
(13, 'wrestling-arena'),
(14, 'just2play'),
(15, 'j2p'),
(16, 'playnion'),
(17, 'egaming'),
(18, 'projectx'),
(19, 'expertgame');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `answers_app`
--

CREATE TABLE `answers_app` (
  `id` int(11) NOT NULL,
  `appid` int(11) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `answer` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `antifraudaraport`
--

CREATE TABLE `antifraudaraport` (
  `id` int(11) NOT NULL,
  `pid1` int(11) NOT NULL,
  `pid2` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `aplications`
--

CREATE TABLE `aplications` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(69) NOT NULL DEFAULT 0,
  `factionid` int(69) NOT NULL DEFAULT 0,
  `playerid` int(69) NOT NULL,
  `actionby` varchar(50) NOT NULL,
  `r1` varchar(128) NOT NULL,
  `r2` varchar(128) NOT NULL,
  `r3` varchar(128) NOT NULL,
  `r4` varchar(128) NOT NULL,
  `r5` varchar(128) NOT NULL,
  `r6` varchar(128) NOT NULL,
  `r7` varchar(128) NOT NULL,
  `r8` varchar(128) NOT NULL,
  `r9` varchar(128) NOT NULL,
  `r10` varchar(128) NOT NULL,
  `r11` varchar(128) NOT NULL,
  `r12` varchar(128) NOT NULL,
  `r13` varchar(128) NOT NULL,
  `r14` varchar(128) NOT NULL,
  `r15` varchar(128) NOT NULL,
  `q1` varchar(128) NOT NULL,
  `q2` varchar(128) NOT NULL,
  `q3` varchar(128) NOT NULL,
  `q4` varchar(128) NOT NULL,
  `q5` varchar(128) NOT NULL,
  `q6` varchar(128) NOT NULL,
  `q7` varchar(128) NOT NULL,
  `q8` varchar(128) NOT NULL,
  `q9` varchar(128) NOT NULL,
  `q10` varchar(128) NOT NULL,
  `q11` varchar(128) NOT NULL,
  `q12` varchar(128) NOT NULL,
  `q13` varchar(128) NOT NULL,
  `q14` varchar(128) NOT NULL,
  `q15` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `atms`
--

CREATE TABLE `atms` (
  `atmId` int(11) NOT NULL,
  `atmPosX` float NOT NULL,
  `atmPosY` float NOT NULL,
  `atmPosZ` float NOT NULL,
  `atmPosRotX` float NOT NULL,
  `atmPosRotY` float NOT NULL,
  `atmPosRotZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `atms`
--

INSERT INTO `atms` (`atmId`, `atmPosX`, `atmPosY`, `atmPosZ`, `atmPosRotX`, `atmPosRotY`, `atmPosRotZ`) VALUES
(1, 2228.39, -1707.78, 12.55, 0, 0, 270),
(2, 2228.39, -1707.78, 12.55, 0, 0, 270),
(3, 1275.8, 368.315, 18.4976, 0, 0, 73.7599),
(4, 1260.88, 209.302, 18.4976, 0, 0, 65.5046),
(5, 2303.46, -13.5396, 25.4273, 0, 0, 272.435),
(6, 2316.1, -88.5226, 25.4273, 0, 0, 0),
(7, 1155.62, -1464.91, 14.7432, 0, 0, 290.21),
(8, 387.166, -1816.05, 6.78341, 0, 0, 272.48),
(9, -24.385, -92.0011, 1002.49, 0, 0, 180.541),
(10, -31.8112, -58.106, 1002.49, 0, 0, 181.216),
(11, 1212.78, 2.45176, 999.865, 0, 0, 0),
(12, 2324.4, -1644.94, 13.7699, 0, 0, 0),
(13, 651.193, -520.488, 15.2788, 0, 0, 0),
(14, 691.082, -618.562, 15.2788, 0, 0, 268.691),
(15, 45.7804, -291.809, 0.802401, 0, 0, 182.934),
(16, 173.235, -155.076, 0.521025, 0, 0, 89.73),
(17, 294.8, -84.01, 1000.3, 0, 0, 90),
(18, 2065.44, -1897.55, 12.4967, 0, 0, 0),
(19, 1497.75, -1749.87, 14.3882, 0, 0, 177.381),
(20, 2093.51, -1359.55, 22.9273, 0, 0, 0),
(21, 2139.45, -1164.08, 22.9351, 0, 0, 91.3095),
(22, 1482.78, -1010.34, 25.7866, 0, 0, 0),
(23, -1835.6, 63.2456, 1054.13, 0, 0, 270),
(24, -1835.6, 64.5987, 1054.13, 0, 0, 270);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `banlog`
--

CREATE TABLE `banlog` (
  `ID` int(11) NOT NULL,
  `ip` varchar(25) NOT NULL,
  `player` varchar(25) NOT NULL,
  `admin` varchar(25) NOT NULL,
  `reason` varchar(60) NOT NULL,
  `day` int(11) NOT NULL DEFAULT 0,
  `time` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bans`
--

CREATE TABLE `bans` (
  `ID` int(11) NOT NULL,
  `PlayerName` varchar(30) NOT NULL,
  `AdminName` varchar(30) NOT NULL,
  `Reason` varchar(128) NOT NULL,
  `IP` varchar(16) NOT NULL,
  `Days` int(11) NOT NULL,
  `IPBan` int(11) NOT NULL,
  `Permanent` int(11) NOT NULL,
  `Time` int(15) NOT NULL,
  `BanTimeDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `bizz`
--

CREATE TABLE `bizz` (
  `ID` int(11) NOT NULL,
  `Owned` int(2) NOT NULL,
  `Owner` varchar(25) NOT NULL DEFAULT 'The State',
  `Message` varchar(50) NOT NULL,
  `EntranceX` float NOT NULL,
  `EntranceY` float NOT NULL,
  `EntranceZ` float NOT NULL,
  `ExitX` float NOT NULL,
  `ExitY` float NOT NULL,
  `ExitZ` float NOT NULL,
  `LevelNeeded` int(11) NOT NULL DEFAULT 15,
  `BuyPrice` int(11) NOT NULL DEFAULT 20000000,
  `EntranceCost` int(11) NOT NULL DEFAULT 5,
  `Till` int(11) NOT NULL,
  `Sbiz` int(2) NOT NULL,
  `Type` int(3) NOT NULL,
  `Locked` int(11) NOT NULL,
  `Interior` int(11) NOT NULL,
  `Virtual` int(11) NOT NULL,
  `Prices` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `bizz`
--

INSERT INTO `bizz` (`ID`, `Owned`, `Owner`, `Message`, `EntranceX`, `EntranceY`, `EntranceZ`, `ExitX`, `ExitY`, `ExitZ`, `LevelNeeded`, `BuyPrice`, `EntranceCost`, `Till`, `Sbiz`, `Type`, `Locked`, `Interior`, `Virtual`, `Prices`) VALUES
(1, 1, 'Sko0L.', 'Banca LS ', 1460.23, -1010.7, 26.8438, 2306, -16, 27, 15, 10000000, 2000, 2514000, 0, 1, 0, 0, 0, 0),
(2, 1, 'Alex', 'Faceti DM, va provoc', 1367.99, -1279.75, 13.5469, 315.74, -143.093, 999.602, 7, 2, 2000, 2005800, 0, 2, 0, 7, 0, 0),
(3, 1, 'JamaikaONE', 'DE VANZARE * Profit ', 1836.09, -1682.5, 13.3624, 493.46, -24.0736, 1000.68, 7, 10000000, 2000, 25770, 0, 3, 0, 17, 0, 100000000),
(4, 1, 'Roberto', 'Cluckin Bell', 2102.38, 2228.72, 11.0234, 364.942, -11.0787, 1001.85, 7, 10000000, 2000, 19260, 0, 14, 0, 9, 0, 0),
(5, 1, 'KillerMinutz1', 'Club Blue Night ', 2421.41, -1220.3, 25.4937, 1204.83, -13.4011, 1000.92, 7, 10000000, 2000, 41135, 0, 3, 0, 2, 0, 1000000000),
(6, 1, 'Marga', 'Cel mai bun Bar!', 2309.85, -1643.54, 14.827, -794.942, 490.782, 1376.2, 7, 10000000, 2000, 34830, 0, 3, 0, 1, 0, 65000000),
(7, 1, 'Dan130', 'Daca intri vezi SEX', 1087.63, -923.003, 43.3906, -100.403, -24.3921, 1000.72, 7, 10000000, 2000, 82605, 0, 4, 0, 3, 0, 250000000),
(8, 1, 'SCOoBY', 'Casino Las Venturas', 2019.6, 1007.68, 10.8203, 2015.45, 1017.09, 996.875, 7, 10000000, 2000, 634000, 0, 5, 0, 10, 1, 0),
(9, 1, 'Veer', 'Intrarea este free', 1791.71, -1163.6, 23.8281, 315.74, -143.093, 999.602, 7, 10000000, 1, 484028, 0, 2, 0, 7, 1, 700000000),
(10, 1, 'PaulR', 'Vinde pestele', 1352.16, -1759.17, 13.5078, -31.0246, -91.3283, 1003.55, 7, 10000000, 2000, 1156010, 0, 6, 0, 18, 0, 0),
(11, 1, 'SteelBull', 'SteelBull  are bani', 999.932, -919.889, 42.3281, -31.0246, -91.3283, 1003.55, 7, 10000000, 2000, 732000, 0, 6, 0, 18, 1, 0),
(12, 1, 'panzani', '24/7 Spawn civil!', 1833.14, -1842.5, 13.5781, -31.0246, -91.3283, 1003.55, 7, 10000000, 2000, 560850, 0, 6, 0, 18, 2, 0),
(13, 1, 'ZerG.INVALUiRE', 'Big Smoke Order', 1929.37, -1776.14, 13.5469, -31.0246, -91.3283, 1003.55, 7, 10000000, 2000, 15100, 0, 6, 0, 18, 3, 0),
(14, 1, 'TransparenT', '[Valoare $$$}', 1315.7, -898.097, 39.5781, -31.0246, -91.3283, 1003.55, 7, 10000000, 1000, 124600, 0, 6, 0, 18, 4, 0),
(15, 1, 'Big.A', 'Hai la McDonald', 1199.38, -919.098, 43.1152, 363.134, -74.8469, 1001.51, 7, 10000000, 2000, 197365, 0, 7, 0, 10, 0, 0),
(16, 1, 'NoXe', 'cit vr pe faina ', 810.737, -1616.19, 13.5469, 363.134, -74.8469, 1001.51, 7, 10000000, 2000, 756535, 0, 7, 0, 10, 1, 0),
(17, 1, 'RobertGT', 'RobertGT FORTA !!!', 2472.79, 2034.26, 11.0625, 363.134, -74.8469, 1001.51, 7, 10000000, 2000, 7740, 0, 7, 0, 10, 2, 30000000),
(18, 1, 'AdmBot', 'Burger LV.', 1158.14, 2072.27, 11.0625, 363.134, -74.8469, 1001.51, 7, 10000000, 5, 0, 0, 7, 0, 10, 3, 30000000),
(19, 1, 'BogdyFace', 'Sorry', 2170.06, 2795.64, 10.8203, 363.134, -74.8469, 1001.51, 7, 30000000, 2000, 6800, 0, 7, 0, 10, 4, 30000000),
(20, 1, 'Mike', 'McDonald\'s', 1872.71, 2071.67, 11.0625, 363.134, -74.8469, 1001.51, 7, 10000000, 2000, 13400, 0, 7, 0, 10, 5, 60000000),
(21, 1, 'MYTZU', 'Banca LV', 2194.99, 1676.89, 12.3672, 2306, -16, 27, 7, 10000000, 2000, 1232125, 0, 1, 0, 0, 1, 0),
(22, 1, 'p0w3r', 'Gun Shop p0w3r', 2556.62, 2063.98, 11.0995, 316, -142, 1000, 7, 10000000, 2000, 143000, 0, 2, 0, 7, 2, 300000000),
(23, 1, 'AdmBot', 'Sex Shop LV', 2515.95, 2297.69, 10.8203, -100.403, -24.3921, 1000.72, 7, 10000000, 5, 315, 0, 4, 0, 3, 1, 30000000),
(24, 1, 'InMemoryOfPaulWalker', 'FISH LV - 24/7 ', 2637.61, 1129.28, 11.1797, -31.0246, -91.3283, 1003.55, 7, 10000000, 1, 39434, 0, 6, 0, 18, 5, 0),
(25, 1, '=zeus=boss', 'bine ati venit', 2229.22, -1721.89, 13.5671, 772.112, -3.89865, 1000.73, 7, 10000000, 2000, 1250000, 0, 8, 0, 5, 0, 0),
(26, 1, 'Gaman', 'De vanzare', 2104.57, -1806.67, 13.5547, 372.54, -133.009, 1001.49, 7, 10000000, 2000, 51600, 0, 9, 0, 5, 6, 0),
(27, 1, 'Alexandru', 'Nema dobanda ', 1102.91, -1440.13, 15.7969, 2306, -16, 27, 7, 10000000, 2000, 150000, 0, 1, 0, 0, 2, 0),
(28, 1, 'AdmBot', 'Cienen Lous Santos', 1168.43, -1489.36, 22.757, 0, 0, 0, 7, 11, 2000, 3847050, 1, 15, 0, 0, 0, 0),
(29, 1, 'StarssAdv', '[!] #LEGEND [!]', 2102.56, 2257.37, 11.0234, 207.738, -109.02, 1005.13, 7, 10000000, 2000, 97000, 0, 11, 0, 15, 2, 0),
(30, 1, 'WiTTy..', '#NiKE #Adidas [AIM]', 499.936, -1359.74, 16.2911, 161.391, -93.1592, 1001.8, 7, 10000000, 2000, 80000, 0, 11, 0, 18, 0, 150000000),
(31, 1, 'Iynu.', 'Fast And Furious', 517.787, -1296.58, 17.2422, 0, 0, 0, 7, 10000000, 2000, 21880, 1, 10, 0, 0, 0, 60000000),
(32, 1, 'PLAY', 'Bync0 pRiNciPaL', 1456.98, -1138.04, 23.9778, 161.391, -93.1592, 1001.8, 7, 10000000, 2000, 920205, 0, 11, 0, 18, 1, 0),
(33, 1, 'Roby', 'Gas Station', 1941.6, -1764.74, 13.6406, 0, 0, 0, 7, 10000000, 2000, 201840, 1, 12, 0, 0, 0, 100000000),
(34, 1, 'Jayler', 'PNS Dillimore! ', 723.409, -463.627, 16.3359, 0, 0, 0, 7, 10000000, 2000, 118000, 1, 13, 0, 0, 0, 0),
(35, 1, 'Damien.', 'Damien.`s PNS', 2072.57, -1828.03, 13.5469, 0, 0, 0, 7, 10000000, 2000, 72000, 1, 13, 1, 0, 0, 0),
(36, 1, 'Skunk', 'PNS Central', 1034.7, -1028.1, 32.1016, 0, 0, 0, 7, 20000000, 2000, 2282000, 1, 13, 0, 0, 0, 0),
(37, 1, 'qM3nTOL', 'Reparati la M3nTOL', 485.37, -1733.32, 11.094, 0, 0, 0, 7, 10000000, 2000, 988000, 1, 13, 0, 0, 0, 450000000),
(38, 1, 'Bahoi', 'BAICOI TUNING', 1037.11, -1025.04, 32.1016, 0, 0, 0, 7, 20000000, 2000, 368000, 1, 16, 0, 0, 0, 500000000),
(39, 1, 'AdmBot', 'Mod Shop', 2650.33, -2021.76, 14.1766, 0, 0, 0, 7, 10000000, 5, 225, 1, 16, 0, 0, 0, 30000000),
(40, 1, 'AdmBot', 'Reparati la M3nTOL', 1966.45, 2156.36, 10.8203, 0, 0, 0, 7, 10000000, 5, 735, 1, 13, 0, 0, 0, 0),
(41, 1, 'Bozzghy', 'PNS Grove Street <3', -94.1097, 1109.86, 19.7422, 0, 0, 0, 7, 10000000, 2000, 148000, 1, 13, 0, 0, 0, 0),
(42, 1, 'spacekill', 'La SpaceKill', 1012.9, -935.545, 42.1797, 0, 0, 0, 7, 10000000, 1999, 482780, 1, 12, 0, 0, 0, 0),
(43, 1, 'SnK.', 'Benzinaria LS', 655.566, -572.436, 16.5015, 0, 0, 0, 7, 10000000, 5, 19540, 1, 12, 0, 0, 0, 0),
(44, 1, 'Nfs', 'Gas Station', -78.6301, -1169.16, 2.1491, 0, 0, 0, 7, 10000000, 2000, 27620, 1, 12, 0, 0, 0, 0),
(45, 1, 'AdmBot', 'Gas Station', 2646.33, 1101.31, 10.9609, 0, 0, 0, 7, 10000000, 5, 4200, 1, 12, 0, 0, 0, 0),
(46, 1, 'AdmBot', 'Gas Station', 2139.81, 2753.5, 10.8203, 0, 0, 0, 7, 10000000, 5, 2000, 1, 12, 0, 0, 0, 30000000),
(47, 1, 'AdmBot', 'Gas Station', 2207.51, 2482.56, 10.8203, 0, 0, 0, 7, 10000000, 5, 2880, 1, 12, 0, 0, 0, 30000000),
(48, 1, 'AdmBot', 'Gas Station', 1604.09, 2204.47, 10.8203, 0, 0, 0, 7, 10000000, 5, 12420, 1, 12, 0, 0, 0, 30000000),
(49, 1, 'LuKSs', 'Combustibil bun!', 2122.56, 914.539, 10.8203, 0, 0, 0, 7, 10000000, 2000, 0, 1, 12, 0, 0, 0, 55000000),
(50, 1, 'piMp', 'Gas Station', 638.368, 1683.78, 7.1875, 0, 0, 0, 7, 10000000, 5, 0, 1, 12, 0, 0, 0, 0),
(51, 1, 'sKim.', 'PNS Intrare LV !', 2392.17, 1042.01, 10.8203, 0, 0, 0, 7, 10000000, 2000, 118000, 1, 16, 0, 0, 0, 0),
(52, 1, 'GlazKo', 'CNN LV', 2079.2, 2045.07, 11.0579, 0, 0, 0, 7, 10000000, 2000, 1830600, 1, 15, 0, 0, 0, 0),
(53, 1, 'StingerClock39', 'Eugen\'s Style', 2244.38, -1665.16, 15.4766, 207.738, -109.02, 1005.13, 7, 10000000, 2000, 795680, 0, 11, 0, 15, 1, 200000000),
(54, 1, 'AdmBot', 'Cluckin Bell', 172.527, 1176.09, 14.7645, 364.942, -11.0787, 1001.85, 7, 10000000, 5, 10, 0, 14, 0, 9, 1, 0);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `blockedaccounts`
--

CREATE TABLE `blockedaccounts` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `gpci` varchar(129) NOT NULL,
  `key` varchar(64) NOT NULL,
  `unblock` int(11) NOT NULL,
  `linkexpire` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `cars`
--

CREATE TABLE `cars` (
  `ID` int(11) NOT NULL,
  `Model` int(11) NOT NULL,
  `Locationx` float NOT NULL,
  `Locationy` float NOT NULL,
  `Locationz` float NOT NULL,
  `Angle` float NOT NULL,
  `Locationx2` float NOT NULL,
  `Locationy2` float NOT NULL,
  `Locationz2` float NOT NULL,
  `Angle2` float NOT NULL,
  `ColorOne` int(11) NOT NULL,
  `ColorTwo` int(11) NOT NULL,
  `Owner` varchar(25) NOT NULL DEFAULT 'Dealership',
  `Value` int(20) NOT NULL,
  `License` varchar(20) NOT NULL DEFAULT 'NewCar',
  `Description` varchar(50) NOT NULL,
  `Lockk` int(3) NOT NULL,
  `Timed` int(11) NOT NULL,
  `Inscarprice` int(11) NOT NULL,
  `Insurancecar` int(11) NOT NULL,
  `KM` float NOT NULL,
  `HP` float NOT NULL DEFAULT 1000,
  `Gas` int(3) NOT NULL DEFAULT 100,
  `Damage1` int(11) NOT NULL DEFAULT 0,
  `Damage2` int(11) NOT NULL DEFAULT 0,
  `Damage3` int(11) NOT NULL DEFAULT 0,
  `Damage4` int(11) NOT NULL DEFAULT 0,
  `Owned` int(11) NOT NULL,
  `Spawned` int(11) NOT NULL,
  `Sell` int(11) NOT NULL,
  `mod1` int(24) NOT NULL,
  `mod2` int(24) NOT NULL,
  `mod3` int(24) NOT NULL,
  `mod4` int(24) NOT NULL,
  `mod5` int(24) NOT NULL,
  `mod6` int(24) NOT NULL,
  `mod7` int(24) NOT NULL,
  `mod8` int(24) NOT NULL,
  `mod9` int(24) NOT NULL,
  `mod10` int(24) NOT NULL,
  `mod11` int(24) NOT NULL,
  `mod12` int(24) NOT NULL,
  `mod13` int(24) NOT NULL,
  `mod14` int(24) NOT NULL,
  `mod15` int(24) NOT NULL,
  `mod16` int(24) NOT NULL,
  `mod17` int(24) NOT NULL,
  `PaintJ` int(24) NOT NULL DEFAULT 6,
  `days` int(11) NOT NULL DEFAULT 0,
  `BuyTime` int(11) NOT NULL,
  `CarHP` int(11) NOT NULL DEFAULT 1000,
  `CarFuel` int(11) NOT NULL DEFAULT 100,
  `LastKM` int(11) NOT NULL DEFAULT 0,
  `VIP` int(2) NOT NULL DEFAULT 0,
  `VipText` varchar(20) NOT NULL,
  `VipColor` int(3) NOT NULL DEFAULT 0,
  `Block` int(11) NOT NULL DEFAULT 0,
  `Event` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `changemail`
--

CREATE TABLE `changemail` (
  `ChangeMailKey` varchar(255) NOT NULL DEFAULT '',
  `name` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `chat_logs`
--

CREATE TABLE `chat_logs` (
  `ID` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `text` varchar(128) NOT NULL,
  `where` varchar(10) NOT NULL DEFAULT 'chat',
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `clancars`
--

CREATE TABLE `clancars` (
  `ID` int(11) NOT NULL,
  `Model` int(11) NOT NULL,
  `Locationx` float NOT NULL,
  `Locationy` float NOT NULL,
  `Locationz` float NOT NULL,
  `Angle` float NOT NULL,
  `ColorOne` int(11) NOT NULL,
  `ColorTwo` int(11) NOT NULL,
  `Owner` varchar(50) NOT NULL,
  `Value` int(11) NOT NULL,
  `License` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `clans`
--

CREATE TABLE `clans` (
  `clanID` int(12) NOT NULL,
  `clanName` varchar(255) NOT NULL,
  `clanMOTD` varchar(128) NOT NULL,
  `clanTag` varchar(255) NOT NULL DEFAULT '[NONE]',
  `clanRankName7` varchar(32) NOT NULL DEFAULT 'Owner',
  `clanRankName1` varchar(32) NOT NULL DEFAULT 'Newbie',
  `clanRankName2` varchar(32) NOT NULL DEFAULT 'Member',
  `clanRankName3` varchar(32) NOT NULL DEFAULT 'Advanced',
  `clanRankName4` varchar(32) NOT NULL DEFAULT 'Expert',
  `clanRankName5` varchar(32) NOT NULL DEFAULT 'Legend',
  `clanRankName6` varchar(32) NOT NULL DEFAULT 'Manager',
  `clanSlots` int(11) NOT NULL DEFAULT 25,
  `clanCreated` varchar(30) NOT NULL,
  `clanExpire` int(11) NOT NULL,
  `clanActive` int(11) NOT NULL DEFAULT 1,
  `clanColor` varchar(10) NOT NULL DEFAULT 'FFCC99',
  `clanDescription` text NOT NULL,
  `clanForum` varchar(50) NOT NULL,
  `clanAdminEdit` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `clan_logs`
--

CREATE TABLE `clan_logs` (
  `id` int(11) NOT NULL,
  `clanid` int(11) NOT NULL,
  `action` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `playername` int(30) NOT NULL,
  `createdby` int(30) NOT NULL,
  `time` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `reasoncomplaint` int(11) NOT NULL,
  `evidence` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `details` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `ip` varchar(20) NOT NULL,
  `factionid` int(11) NOT NULL,
  `faction` int(11) NOT NULL,
  `unixtime` int(11) NOT NULL,
  `deleted` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `donatiibre`
--

CREATE TABLE `donatiibre` (
  `donateID` int(11) NOT NULL,
  `donateName` varchar(30) NOT NULL,
  `donatePIN` varchar(19) NOT NULL,
  `donateSUM` varchar(3) NOT NULL,
  `donateStatus` int(11) NOT NULL,
  `donateTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `donateAdminAction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `donations`
--

CREATE TABLE `donations` (
  `donateID` int(11) NOT NULL,
  `donateName` varchar(30) NOT NULL,
  `donatePIN` varchar(19) NOT NULL,
  `donateSUM` varchar(3) NOT NULL,
  `donateStatus` int(11) NOT NULL,
  `donateTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `donateAdminAction` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `emails`
--

CREATE TABLE `emails` (
  `ID` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL DEFAULT 0,
  `Message` varchar(500) NOT NULL,
  `EmailRead` int(11) NOT NULL DEFAULT 1,
  `LinkPanel` text NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `unixtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `eventobjects`
--

CREATE TABLE `eventobjects` (
  `id` int(11) NOT NULL,
  `objModel` int(11) NOT NULL DEFAULT 19058,
  `objPosX` float NOT NULL DEFAULT 0,
  `objPosY` float NOT NULL DEFAULT 0,
  `objPosZ` float NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `eventobjects`
--

INSERT INTO `eventobjects` (`id`, `objModel`, `objPosX`, `objPosY`, `objPosZ`) VALUES
(1, 19054, 1666.72, -2091.26, 13.5469),
(2, 19054, 2389.22, -2503.33, 18.9217),
(3, 19054, 2793.42, -1626.46, 10.9219),
(4, 19054, 2583.53, -969.09, 84.4583),
(5, 19054, 2063.25, -914.167, 99.2081),
(6, 19054, 2123.88, -1160.1, 24.1991),
(7, 19054, 2398.29, -1691.17, 13.7097),
(8, 19054, 2243.01, -2058.21, 17.2712),
(9, 19054, 1975.98, -1202.36, 16.6019),
(10, 19054, 1534.83, -1002.25, 43.7328),
(11, 19054, 1827.58, -1021.41, 24.5421),
(12, 19054, 1177.4, -1159.24, 33.228),
(13, 19054, 1134.72, -1560.14, 22.7521),
(14, 19054, 723.119, -1491.72, -1.7772),
(15, 19054, 295.818, -1439.67, 31.3678),
(16, 19054, 448.724, -1354.02, 14.8356),
(17, 19054, 340.56, -1287.3, 52.7521),
(18, 19054, 154.235, -1946.16, 5.105),
(19, 19054, 847.058, -2068.79, 11.8191),
(20, 19054, 1084.69, -2239.76, 47.2973),
(21, 19054, 1644.15, -1689.18, 21.4118),
(22, 19054, -392.615, -1434.01, 30.2557),
(23, 19054, 281.267, -944.363, 41.2109),
(24, 19054, 1184.19, -634.389, 81.3521),
(25, 19054, 813.333, -1005.74, 27.9797),
(26, 19058, 2887.36, 956.503, 20.7346),
(27, 19058, 2362.17, 465.953, -5.8057),
(28, 19058, 1532.12, 750.994, 32.7705),
(29, 19058, 1087.86, 1077.45, 10.8382),
(30, 19058, 1100.68, 1597.72, 12.5469),
(31, 19058, 563.606, 875.433, -36.1204),
(32, 19058, 928.742, 2758.14, 26.4127),
(33, 19058, 1780.21, 2815.84, 8.3359),
(34, 19058, 2006.17, 2980.74, -6.702),
(35, 19058, 2609.84, 2848.85, 10.8203),
(36, 19058, 2323.67, 1283.21, 97.6216),
(37, 19058, 2220.94, 1048.64, 10.8203),
(38, 19058, 1984.45, 1028.2, 10.8203),
(39, 19058, 1998.31, 1585.52, 14.8901),
(40, 19058, 1162.56, 2808.51, 27.8976),
(41, 19058, 1020.28, 2066.21, 18.9297),
(42, 19058, 1826.27, 2274.72, 8.2727),
(43, 19058, 1973.85, 2265.84, 14.2464),
(44, 19058, 2225.09, 2529.35, 17.3966),
(45, 19058, 2822.67, 2186.17, 13.8722),
(46, 19058, 2567.87, 2388.05, 15.85),
(47, 19058, 2894.62, 1595.88, 10.8203),
(48, 19058, 1605.27, 1165.18, 10.8125),
(49, 19058, 1572.39, 1669.68, 18.8222),
(50, 19058, 1395.41, 2164.44, 9.7578);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `factionlog`
--

CREATE TABLE `factionlog` (
  `ID` int(11) NOT NULL,
  `factionid` int(11) NOT NULL,
  `player` int(11) NOT NULL,
  `leader` int(11) NOT NULL,
  `action` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `factions`
--

CREATE TABLE `factions` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `X` float NOT NULL,
  `Y` float NOT NULL,
  `Z` float NOT NULL,
  `eX` float NOT NULL DEFAULT 0,
  `eY` float NOT NULL DEFAULT 0,
  `eZ` float NOT NULL DEFAULT 0,
  `SafePos1` float NOT NULL DEFAULT 0,
  `SafePos2` float NOT NULL DEFAULT 0,
  `SafePos3` float NOT NULL DEFAULT 0,
  `Interior` int(5) NOT NULL DEFAULT 0,
  `Virtual` int(5) NOT NULL DEFAULT 0,
  `PickupID` int(11) NOT NULL DEFAULT 1239,
  `MapIcon` int(11) NOT NULL DEFAULT 0,
  `Locked` int(2) NOT NULL DEFAULT 0,
  `Mats` int(11) NOT NULL,
  `Drugs` int(11) NOT NULL,
  `Bank` int(11) NOT NULL,
  `Anunt` varchar(128) NOT NULL,
  `Win` int(11) NOT NULL DEFAULT 0,
  `Lost` int(11) NOT NULL DEFAULT 0,
  `MaxMembers` int(11) NOT NULL DEFAULT 10,
  `MinLevel` int(3) NOT NULL DEFAULT 5,
  `Application` int(11) NOT NULL DEFAULT 0,
  `Rank1` varchar(64) NOT NULL DEFAULT 'Rank1',
  `Rank2` varchar(64) NOT NULL DEFAULT 'Rank2',
  `Rank3` varchar(64) NOT NULL DEFAULT 'Rank3',
  `Rank4` varchar(64) NOT NULL DEFAULT 'Rank4',
  `Rank5` varchar(64) NOT NULL DEFAULT 'Rank5',
  `Rank6` varchar(64) NOT NULL DEFAULT 'Rank6',
  `Rank7` varchar(64) NOT NULL DEFAULT 'Rank7',
  `Skin0` int(3) NOT NULL DEFAULT 0,
  `Skin1` int(3) NOT NULL DEFAULT 0,
  `Skin2` int(3) NOT NULL DEFAULT 0,
  `Skin3` int(3) NOT NULL DEFAULT 0,
  `Skin4` int(3) NOT NULL DEFAULT 0,
  `Skin5` int(3) NOT NULL DEFAULT 0,
  `Skin6` int(3) NOT NULL DEFAULT 0,
  `Skin7` int(3) NOT NULL DEFAULT 0,
  `Skin8` int(3) NOT NULL DEFAULT 0,
  `Skin9` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `factions`
--

INSERT INTO `factions` (`ID`, `Name`, `X`, `Y`, `Z`, `eX`, `eY`, `eZ`, `SafePos1`, `SafePos2`, `SafePos3`, `Interior`, `Virtual`, `PickupID`, `MapIcon`, `Locked`, `Mats`, `Drugs`, `Bank`, `Anunt`, `Win`, `Lost`, `MaxMembers`, `MinLevel`, `Application`, `Rank1`, `Rank2`, `Rank3`, `Rank4`, `Rank5`, `Rank6`, `Rank7`, `Skin0`, `Skin1`, `Skin2`, `Skin3`, `Skin4`, `Skin5`, `Skin6`, `Skin7`, `Skin8`, `Skin9`) VALUES
(1, 'Los Santos Police Department', 246.869, 62.8318, 1003.64, 1554.83, -1675.61, 16.1953, 256.983, 64.637, 1003.64, 6, 0, 1247, 30, 0, 708250, 237, 14555590, 'Skinurile au fost updatate(Check Forum). Sedinta Duminica la ora 15:00(OBLIGATORIE).', 0, 0, 15, 7, 1, 'Cadet', 'Officer', 'Sergeant', 'Inspector', 'Captain', 'Sub-Chestor LSPD', 'Chestor LSPD', 71, 265, 266, 267, 280, 281, 282, 283, 284, 309),
(2, 'Federal Bureau of Investigations', 246.579, 107.928, 1003.22, 627.616, -571.792, 17.6242, 256.68, 120.442, 1003.22, 10, 22, 1247, 30, 1, 45501, 42, 20352037, 'Mini sedinta cand va fi gata panel-u.Sedinta pentru rank-up si salari va Duminca la ora 20:00.', 0, 0, 15, 7, 1, 'Trial Agent', 'Special Agent', 'Special Advisor', 'Main Inspector', 'Executive Chief', 'Consultant of Leader', 'Chestor F.B.I.', 76, 163, 164, 165, 166, 286, 295, 307, 0, 0),
(3, 'National Guard', 288.771, 166.975, 1007.17, 200.766, 1869.49, 13.147, 289.125, 187.97, 1007.18, 3, 1003, 1247, 30, 1, 35400, 163, 24289630, 'Duminica 20:30 Sedinta obligatorie!! Raportul sa il aveti facut!', 0, 0, 15, 7, 1, 'National Guard Soldat', 'National Guard Sergent', 'National Guard Maior ', 'National Guard Locotenent', 'National Guard Comandat', 'National Guard Sub-Chestor', 'National Guard Chestor', 150, 211, 273, 285, 287, 0, 0, 0, 0, 0),
(4, 'Los Aztecas', 2544.7, -1305.07, 1054.64, 1456.74, 2773.34, 10.8203, 2546.8, -1281.24, 1060.98, 2, 1, 1254, 0, 1, 397001, 1101, 7799102, 'Maine 8.03 zi de war! Toti HQ la 19:45! ', 0, 0, 15, 6, 1, 'Kaikei', 'Shatei', 'Kyodai', 'Saiko-Komon', 'Shateigashira', 'Wakagashira', 'Oyabun', 113, 114, 115, 116, 121, 148, 291, 0, 0, 0),
(5, 'Grove Street', 2544.7, -1305.07, 1054.64, 2495.33, -1690.67, 14.7656, 2546.8, -1281.11, 1060.98, 2, 2, 1254, 0, 1, 1521650, 1545, 22401560, 'Vã puteti apuca de raport. Raportul este de 35k materiale, succes!', 0, 0, 15, 6, 1, 'Junior', 'Original Gangster', 'Double OG', 'Triple OG', 'Lieutenant', 'LorD Of Grove', 'KiNG Of Grove', 55, 106, 107, 169, 269, 270, 271, 292, 293, 0),
(6, 'Los Vagos', 2544.7, -1305.07, 1054.64, 725.677, -1440.45, 13.5391, 2546.84, -1280.94, 1060.98, 2, 3, 1254, 0, 1, 1660449, 1373, 8685835, 'SEDINTA SAMBATA ORA 15:00, CINE NU ARE 50,000 MATS UNINVITE!, CINE NU VINE UNINVITE!', 0, 0, 15, 6, 1, '[1] New Magnific', '[2] Advanced', '[3] Gangsta', '[4] Magnific Terror', '[5] One Of The Best', '[6] Lord Of Vagos', '[7] King Of Vagos', 108, 109, 110, 176, 177, 191, 0, 0, 0, 0),
(7, 'None', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1239, 0, 1, 0, 0, 0, 'None', 0, 0, 15, 0, 0, 'Rank1', 'Rank2', 'Rank3', 'Rank4', 'Rank5', 'Rank6', 'Rank7', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 'Las Venturas Police Department', 246.869, 62.8318, 1003.64, 2287.1, 2431.8, 10.8203, 256.965, 64.732, 1003.64, 6, 3, 1247, 30, 1, 0, 0, 17827800, 'Sedinta are loc in fiecare DUMINICA la ora 13:00.', 0, 0, 15, 7, 0, 'Cadet', 'Officer', 'Sergeant', 'Inspector', 'Captain', 'Lord Of Police', 'God Of Police', 71, 211, 265, 266, 280, 281, 282, 283, 284, 309),
(9, 'News Reporters', 1700.93, -1668.17, 20.2188, -329.526, 1536.78, 76.6117, 1722.83, -1673.18, 20.223, 18, 1, 1239, 0, 1, 10499, 0, 13239974, 'Momentan factiunea nu are lider. Asta nu va impiedica sa va faceti raportul. Spor la treaba. ', 0, 0, 15, 3, 1, 'Reporter', 'Jurnalist', 'Editor', 'Redactor', 'Manager', 'News Reporters Co-Owner', 'News Reporters Owner', 17, 141, 147, 187, 188, 194, 0, 0, 0, 0),
(10, 'Ballas', 2544.7, -1305.07, 1054.64, 1455.27, 750.868, 11.0234, 2546.82, -1280.94, 1060.98, 2, 4, 1254, 0, 1, 4770862, 668, 12967530, 'Luni, miercuri, vineri si duminica toata lumea sus HQ! Cine nu este prezent, Fwarn!', 0, 0, 15, 6, 0, 'Street Fish', 'City Fish', 'Small Pimp', 'Pimp', 'Small Pimp', 'Under-Pimp', 'Pimp', 98, 102, 104, 185, 195, 296, 0, 0, 0, 0),
(11, 'Hitman Agency', 288.771, 166.975, 1007.17, 1081.18, -345.398, 73.9825, 289.274, 187.555, 1007.18, 3, 11, 1239, 0, 1, 13601, 100, 20612234, 'Sedinta sambata la ora 20:30. 19.03.2017', 0, 0, 15, 10, 0, 'Assasin', 'Contract Killer', 'Serial Killer', 'Proffesional Killer', 'Manager', 'Vice-Director', 'Director', 90, 118, 120, 186, 208, 294, 0, 0, 0, 0),
(12, 'School Instructors', 1700.93, -1668.17, 20.2188, 2435.31, 1671.01, 10.8203, 1722.82, -1673.04, 20.223, 18, 3, 1239, 0, 1, 1300, 0, 1767191, 'Duminica la ora 20:00 pe data de 19/03/2017 sedinta in HQ cine lipseste primeste Demitere.', 0, 0, 15, 3, 1, '[1] Invatacel', 'Instructor', 'Advanced Instructor', 'Supervisor', 'Manager', 'Vice-Director', '[7] Director', 11, 153, 171, 172, 189, 240, 0, 0, 0, 0),
(13, 'Taxi', 1727.01, -1638.22, 20.2231, 1753.2, -1903.28, 13.5633, 1722.66, -1672.89, 20.223, 18, 2, 1239, 0, 1, 35399, 1, 4699719, 'Sedinta Duminica, ora 20:00, cine nu va veni va primi FW!', 0, 0, 15, 3, 0, 'Novice Driver', 'Driver', 'Proffesional Driver', 'Legend Driver', 'Manager', 'Vice-Director', 'Leader', 61, 141, 228, 253, 255, 272, 0, 0, 0, 0),
(14, 'Paramedic Department', 288.771, 166.975, 1007.17, 1614.92, 1816.1, 10.8203, 289.11, 188.051, 1007.18, 3, 14, 1239, 22, 1, 10400, 10, 609787, 'Sedinta este pe data de 20.03.2017 la ora 20:00.Sedinta este obligatorie!', 0, 0, 15, 3, 1, 'Paramedic Stagiar', 'Paramedic Rezident', 'Paramedic Chirurg', 'Paramedic Specialist', 'Paramedic Primar', 'Deputy Chief Paramedic', 'Chief Paramedic', 70, 228, 274, 275, 276, 279, 308, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `faction_logs`
--

CREATE TABLE `faction_logs` (
  `ID` int(11) NOT NULL,
  `player` int(11) NOT NULL,
  `leader` int(11) NOT NULL,
  `Text` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `faction_questions`
--

CREATE TABLE `faction_questions` (
  `id` int(11) NOT NULL,
  `factionid` varchar(2) NOT NULL,
  `question` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `faction_questions`
--

INSERT INTO `faction_questions` (`id`, `factionid`, `question`) VALUES
(12, '8', 'Nume real'),
(13, '8', 'Varsta'),
(14, '8', 'Ai mai facut parte dintr-un departament ? Daca da, de ce l-ai parasit?'),
(16, '8', 'Ai probleme cu cineva din Las Venturas Police Departament ?'),
(17, '8', 'Ai posibilitatea de a filma ?'),
(18, '8', 'Esti de accord sa stai in LVPD minim 14 zile ?'),
(19, '8', 'Descrie-te in minim 20 de cuvinte'),
(20, '8', 'De ce doresti sa intri in Las Venturas Police Departament ?'),
(21, '8', 'Cat timp petreci pe SA:MP , zilnic ?'),
(22, '8', 'Crezi ca te vei descurca in acest departament?'),
(44, '3', 'Cu ce se ocupa National Guard?'),
(45, '3', 'Ce fel de factiune este aceasta?(agentie, etc.)'),
(46, '3', 'De ce doresti sa faci parte din aceasta factiune?'),
(47, '3', 'Descrie-ti personalitatea reala in 30 de cuvinte.'),
(48, '3', 'Varsta reala:'),
(49, '3', 'Descrie-ti caracterul din SA:MP in 30 de cuvinte.'),
(50, '3', 'Ai citit regulamentul factiunii?'),
(51, '3', 'Cate ore pe zi acorzi serverului?'),
(52, '3', 'Ai fost vreodata banat? Daca da, din ce motiv?'),
(53, '3', 'De ce meriti sa fii membru al acestei factiuni?'),
(54, '3', 'Poti filma cu Fraps sau Bandicam'),
(83, '6', 'Ce este Los Vagos si cu ce se ocupa?'),
(84, '6', 'Cum te numesti?'),
(85, '6', 'Ce varsta ai?'),
(86, '6', 'Descriete in minim 30 de cuvinte.'),
(87, '6', 'Ai citit regulamentul factiuni?'),
(88, '6', 'De ce vrei sa aplici in Los Vagos?'),
(89, '6', 'Cat de bine tragi cu Deagle/MP4 pe o scara de la 1 la 10?'),
(90, '6', 'Vei respecta Lider-ul incat si Co-Liderul?\\r\\n'),
(91, '6', 'Alte precizari privind comportamentul tau?\\r\\n'),
(92, '2', 'Esti constient ca daca nu respecti liderul factiunii si co-liderul vei fi sanctionat?:'),
(93, '2', 'Ai timpul necesar pentru a termina in decurs de o saptamana raportul stabilit pentru rank-up?:'),
(95, '2', 'Ai fost banat vre-o data pe acest server?:'),
(96, '2', 'Cu ce se ocupa Federal Bucureau of Investigations?'),
(97, '2', 'Ai citit regulamentul factiunii?:'),
(98, '2', 'Varsta reala:'),
(99, '2', 'De ce vrei sa faci parte din aceasta factiune?:'),
(100, '2', 'Ai posibilitatea de a folosii un program de filmat(Bandicam sau Fraps) si un mod cleo de tip COP CMD ?'),
(102, '2', 'Ai primit vre-o data o sanctiune de la admin pe acest cont?:'),
(103, '10', 'De ce doresti sa te alaturi mafiei Ballas Family?'),
(104, '10', 'Intelegi ca este interzis sa folosesti moduri cleo/asi(inclusiv modul de harta patrata si modul de arme pe spate) si sa modifici fisierul samp.dll?'),
(105, '10', 'Intelegi ca daca primesti crash din orice motiv cand esti testat de cheat-uri de catre un admin vei primi ban 7 zile?'),
(106, '10', 'Ai fost banat vreodata pe acest server? Daca da, de ce?'),
(107, '10', 'Cat de bine tragi cu deagle/M4/rifle(excelent/bine/slab):'),
(108, '10', 'Descrie-te in cateva cuvinte:'),
(109, '10', 'Consideri ca poti fi prezent Luni, Miercuri, Vineri si Duminca intre orele 20:00 - 22:00 la war-uri?'),
(110, '10', 'Alte precizari:'),
(114, '1', 'Nickname-uri / conturi anterioare:'),
(115, '1', 'Varsta reala:'),
(116, '1', 'O scurta caracterizare:'),
(117, '1', 'Numarul de ore petrecute pe joc pe zi (fara afk / sleep):'),
(118, '1', 'De ce doresti sa te alaturi acestui departament?'),
(119, '1', 'Care sunt realizarile tale pe server?'),
(120, '1', 'Esti de acord ca daca nu respecti liderul sau co-liderul factiunii sa fi sanctionat cu faction warn sau chiar uninvite?'),
(121, '1', 'Prin ce te-ai remarcat pana acum pe server?'),
(122, '1', 'Alte precizari : '),
(142, '9', 'Nume real:'),
(143, '9', 'Varsta reala:'),
(144, '9', 'Cate ore acorzi jocului pe zi, fara [/sleep]:'),
(145, '9', 'Ai tangente cu vreun membru din factiune?:'),
(146, '9', 'Cu ce se ocupa factiunea News Reporters?:'),
(147, '9', 'De ce doresti sa intri in News Reporters?:'),
(148, '9', 'Esti pe Blacklist-ul unei factiuni?:'),
(150, '9', 'Vei respecta atat liderul cat si membrii?:'),
(151, '9', 'Cum te poti descrie ( minim 35 cuvinte ):'),
(152, '9', 'Esti constient ca vei fi testat din regulamentul factiunii?'),
(153, '9', 'Ai fost banat? Precizeaza numarul si motivul acestora.'),
(154, '9', 'Esti capabil sa scrii corect gramatical?'),
(155, '9', 'Esti constient ca daca stresezi liderul / coliderii iti vei pierde sansa de a fi acceptat?'),
(156, '9', 'Sti ca trebuie sa stai minim 14 zile pentru a nu primi Uninvite cu FP da?'),
(159, '5', 'Cum tragi cu armele: M4, Deagle, Rifle?'),
(160, '5', 'De ce ai aplicat la aceasta mafie si nu la alta grupare?'),
(161, '5', 'Ce varsta ai?'),
(162, '5', 'De cand joci acest joc numit SA:MP?'),
(163, '5', 'Esti de acord ca daca nu postezi 35.000 de materiale pe saptamana sa iei uninvite?'),
(164, '5', 'Esti de acord ca daca nu ai 7 zile in factiune nu poti face cerere de invoire la war/sedinta?'),
(165, '5', 'Poti fii prezent Luni, miercuri, vineri, duminica (20:00-22:00) la waruri?'),
(166, '5', 'Caracterizeaza-te: (in minim 20 de cuvinte)'),
(167, '14', 'Care este numele tau si cati ani ai?'),
(168, '14', 'Prezinta-te in cel putin 20 de cuvinte. '),
(169, '14', 'De ce ai ales aceasta factiune?'),
(170, '14', 'Cu ce crezi ca poti ajuta aceasta factiune? '),
(171, '14', 'Alte precizari?'),
(186, '4', 'Varsta reala:'),
(187, '4', 'Intervalul de timp in care joci pe server:'),
(188, '4', 'Descrierea ta personala in maxim 30 de cuvinte:'),
(189, '4', 'De ce ai aplicat la aceasta mafie si nu la alta?'),
(190, '4', 'Poti venii la waruri?'),
(191, '4', 'Cat de bine stii sa tragi cu armele?'),
(192, '4', 'Mai ai ceva de adaugat?'),
(194, '13', 'Cum te numesti şi care este varsta ta reala ?'),
(196, '13', 'Descrie-te in minim 20 de cuvinte :'),
(201, '13', 'Cat timp ti-ai propus sa stai in aceasta factiune ?'),
(203, '13', 'Care este intervalul orar in care joci ? (aproximeaza) :'),
(204, '13', 'Care crezi ca sunt calitatile unui taximetrist ? :'),
(205, '13', 'Cunosti toate locatiile importante de pe server ? :'),
(206, '13', 'De ce doresti sa faci parte din factiunea Taxi Los Santos?'),
(207, '13', 'Ai tangente cu vreun membru din factiune ?'),
(208, '11', 'Descrie-te in cateva cuvinte (minim 20 de cuvinte)'),
(209, '11', 'Ai mai facut parte din Hitman Agency ? Daca da, de ce ai plecat ?'),
(210, '11', 'Prin ce te-ai remarcat pana acum pe server?'),
(211, '11', 'Cu ce crezi ca se ocupa membrii agentiei?'),
(212, '11', 'De ce doresti sa te alaturi agentiei?'),
(213, '11', 'Cate ore acorzi jocului pe zi, fara [/sleep]?'),
(214, '11', 'Ai fost banat vreodata? Precizeaza numarul banurilor si motivul acestora.'),
(215, '11', 'Esti constient ca vei fi sanctionat daca incalci regulamentul factiunii?'),
(216, '11', 'Link catre profilul de pe forum'),
(217, '11', 'Alte precizari ?'),
(219, '12', 'Cu ce se ocupa factiunea School Instructors? / What does this faction?'),
(220, '12', 'Varsta reala / How old are you?'),
(221, '12', 'In ce consta programul Key Binder? Stii sa il folosesti? / Do you know to use Key Binder?'),
(222, '12', 'Ai fost banat vreodata? Daca da, din ce motiv? / Have you ever been banned? If yes, why?'),
(223, '12', 'Cate ore joci zilnic (fara afk sau /sleep)? / How many hours do you play daily? (No afk or /sleep)'),
(224, '12', 'Explica termenul Deathmatch (DM) / Explain Deathmatch (DM)'),
(225, '12', 'Cum te-ai descrie in cateva cuvinte? (minim 30 de cuvinte) / Describe yourself (at least 30 words)'),
(226, '12', 'Care crezi ca sunt calitatile unui instructor?/What qualities do you think a instructor should have?'),
(227, '12', 'Cat timp vrei sa stai stai in factiune? / How long do you want to stay in this faction?'),
(228, '12', 'De ce vrei sa te alaturi aceste factiuni? / Why you want to join this faction?'),
(229, '12', 'Alte precizari: / Other specifications:'),
(231, '2', 'Spune minim 20 de cuvinte despre tine.'),
(232, '2', 'Ești conștient că nu trebuie sa ceri co-lider?'),
(235, '2', 'Cate ore petreci pe server fara afk/sleep?'),
(236, '2', 'Alte precizări?'),
(238, '9', 'Alte precizari ?');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `frequencies`
--

CREATE TABLE `frequencies` (
  `id` int(11) NOT NULL,
  `freqid` int(5) NOT NULL DEFAULT 100,
  `ownerid` int(11) NOT NULL,
  `password` varchar(20) NOT NULL DEFAULT 'q'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `friends`
--

CREATE TABLE `friends` (
  `ID` int(11) NOT NULL,
  `PlayerID` int(11) NOT NULL,
  `FriendID` int(11) NOT NULL,
  `FriendName` varchar(30) NOT NULL,
  `Status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `garages`
--

CREATE TABLE `garages` (
  `Owner` varchar(24) NOT NULL,
  `Owned` int(2) NOT NULL,
  `Locked` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `PosX` float NOT NULL,
  `PosY` float NOT NULL,
  `PosZ` float NOT NULL,
  `Interior` int(11) NOT NULL,
  `UID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `giftbox_logs`
--

CREATE TABLE `giftbox_logs` (
  `id` int(11) NOT NULL,
  `text` varchar(256) NOT NULL,
  `PlayerID` int(11) NOT NULL,
  `time` varchar(64) NOT NULL DEFAULT '0',
  `giftid` int(11) NOT NULL,
  `puncte` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `globs`
--

CREATE TABLE `globs` (
  `globID` int(11) NOT NULL,
  `GlobPosx` float NOT NULL,
  `GlobPosy` float NOT NULL,
  `GlobPosz` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `globs`
--

INSERT INTO `globs` (`globID`, `GlobPosx`, `GlobPosy`, `GlobPosz`) VALUES
(1, 2048.57, -1727.64, 13.5469),
(2, 1611.25, -1520.81, 13.6105),
(3, 2377.71, -1845.71, 1.69773),
(4, 2507.9, -2429.98, 13.6448),
(5, 1291.03, -2014.47, 58.0814),
(6, 582.335, -1475.92, 14.9447),
(7, 2871.92, 1616.61, 10.8398),
(8, 2796.59, 874.59, 10.7561),
(9, 2276.56, 1124.84, 10.8203),
(10, 1642.52, 1684.3, 10.8203),
(11, 1363.88, 2238.21, 11.2916),
(12, 591.667, 2259.69, 28.4076),
(13, -1416.88, -296.007, 14.1663),
(14, -2145.54, -102.334, 35.3203),
(15, -2646.68, 793.412, 49.9993),
(16, -2685.49, 1379.9, 7.12135),
(17, 1042.69, 1028.05, 11.0171),
(18, -1278.35, 130.431, 3.1907),
(19, -1512.35, 1209.85, 7.1846),
(20, -2635.76, 1438.17, 7.1236);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `houses`
--

CREATE TABLE `houses` (
  `ID` int(11) NOT NULL,
  `Entrancex` float NOT NULL,
  `Entrancey` float NOT NULL,
  `Entrancez` float NOT NULL,
  `Exitx` float NOT NULL,
  `Exity` float NOT NULL,
  `Exitz` float NOT NULL,
  `Owner` varchar(25) NOT NULL DEFAULT 'The State',
  `Discription` varchar(50) NOT NULL DEFAULT 'House',
  `Value` int(20) NOT NULL DEFAULT 10000000,
  `Hel` int(2) NOT NULL DEFAULT 0,
  `Arm` int(2) NOT NULL DEFAULT 0,
  `Music` int(2) DEFAULT 0,
  `Interior` int(11) NOT NULL,
  `InteriorType` int(2) NOT NULL DEFAULT 0,
  `Lockk` int(11) NOT NULL,
  `Owned` int(11) NOT NULL,
  `Rent` int(11) NOT NULL,
  `Rentabil` int(11) NOT NULL,
  `Takings` int(11) NOT NULL,
  `Level` int(11) NOT NULL DEFAULT 10,
  `Virtual` int(11) NOT NULL,
  `Prices` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `houses`
--

INSERT INTO `houses` (`ID`, `Entrancex`, `Entrancey`, `Entrancez`, `Exitx`, `Exity`, `Exitz`, `Owner`, `Discription`, `Value`, `Hel`, `Arm`, `Music`, `Interior`, `InteriorType`, `Lockk`, `Owned`, `Rent`, `Rentabil`, `Takings`, `Level`, `Virtual`, `Prices`) VALUES
(1, 1421.85, -885.64, 50.6647, 295.314, 1472.26, 1080.26, 'xKydux', 'Super 69', 7000000, 0, 0, 0, 15, 1, 0, 1, 69, 1, 15602, 5, 0, 0),
(2, 1468.62, -904.898, 54.8359, 2259.38, -1135.87, 1050.64, 'Nfs', 'Casa Blanca', 5000000, 1, 0, 0, 10, 0, 1, 1, 0, 0, 215, 5, 1, 0),
(3, 1540.46, -851.409, 64.3361, 235.34, 1186.68, 1080.26, 'PaulR', 'V.I.P House.', 7000000, 1, 0, 0, 3, 1, 0, 1, 69, 1, 12480, 5, 2, 0),
(4, 1534.06, -800.188, 72.8495, 223.2, 1287.08, 1082.14, 'AdmBot', 'Dj_YonutZ.', 5000000, 0, 0, 1, 1, 0, 0, 1, 5, 1, 654105, 5, 3, 0),
(5, 1527.3, -773.188, 80.5781, 2283.3, -1140.29, 1050.9, 'Sevast3D', 'Police !', 5000000, 1, 0, 1, 11, 0, 0, 1, 5000, 1, 49999, 5, 4, 0),
(6, 1497.06, -688.239, 95.5086, 2324.53, -1149.54, 1050.71, 'Alex', 'Rent Aici', 0, 0, 0, 0, 12, 2, 0, 1, 5000, 1, 275000, 5, 5, 0),
(7, 1112.11, -742.075, 100.133, 24.04, 1340.17, 1084.38, 'ERROR', '*Phane\'s Residance*', 7000000, 1, 0, 0, 10, 1, 0, 1, 5, 1, 170, 5, 6, 0),
(8, 1093.9, -806.597, 107.419, -283.439, 1471.03, 1084.38, 'CosmiN', '* TWiSTED Residence *', 7000000, 1, 0, 0, 15, 1, 0, 1, 5, 1, 470, 5, 7, 0),
(9, 1034.74, -812.627, 101.852, 447.043, 1397.9, 1084.3, 'Ionutt', 'Casa cu VALOARE!', 7000000, 1, 0, 1, 2, 1, 0, 1, 2500, 1, 20904, 5, 8, 0),
(10, 1095.08, -647.536, 113.648, 225.68, 1021.45, 1084.02, 'Alexandru', 'Music House ', 10000000, 1, 0, 1, 7, 2, 0, 1, 5000, 1, 30000, 5, 9, 0),
(11, 980.352, -676.742, 121.976, 140.17, 1366.07, 1083.65, 'AdmBot', 'BigZone', 10000000, 1, 0, 0, 5, 2, 0, 1, 5, 1, 510130, 5, 10, 0),
(12, 990.004, -828.547, 95.4686, 2308.77, -1212.94, 1049.02, 'AdmBot', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 5, 1, 90, 5, 11, 0),
(13, 937.327, -847.405, 93.7796, 223.005, 1287.6, 1082.14, 'AdmBot', 'Casa de Lux', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 265, 5, 12, 0),
(14, 836.166, -894.341, 68.7689, 226.47, 1114.35, 1080.99, 'PLAY', 'HANU BAICOI', 15000000, 0, 0, 1, 5, 2, 0, 1, 500, 1, 344694, 20, 13, 0),
(15, 827.889, -858.718, 70.3308, 266.5, 304.9, 999.148, 'AdmBot', 'Luccy\'s House.', 5000000, 0, 0, 0, 2, 0, 0, 1, 5, 1, 515, 5, 14, 0),
(16, 1981.29, -1718.79, 17.0301, 2495.74, -1692.82, 1014.74, 'Big.A', '[``\"Big.A\"``]', 7000000, 1, 0, 1, 3, 1, 0, 1, 5, 1, 730, 5, 15, 0),
(17, 2413.86, -1646.79, 14.0119, 243.72, 304.91, 999.148, 'Vlad.WARMACHINE', 'POWER PUFF COMUNITY :))', 5000000, 0, 0, 1, 1, 0, 0, 1, 5000, 1, 425379, 5, 16, 0),
(18, 1854.1, -1914.87, 15.2568, 24.04, 1340.17, 1084.38, 'Sabin2k17', 'Sabin\r\nAlexandru', 10000000, 1, 0, 1, 10, 1, 0, 1, 2500, 1, 557500, 5, 17, 200000000),
(19, 1872.32, -1912.36, 15.2568, 83.03, 1322.28, 1083.87, 'AdmBot', 'Rank 6', 7000000, 0, 0, 1, 9, 1, 0, 1, 5, 1, 50030, 5, 18, 0),
(20, 1891.93, -1914.4, 15.2568, 2317.89, -1026.76, 1050.22, 'Steam_SAMOD', 'VilaJamaicani', 7000000, 1, 0, 0, 9, 1, 0, 1, 5000, 1, 245000, 5, 19, 0),
(21, 1913.51, -1911.9, 15.2568, -42.59, 1405.47, 1084.43, 'Mihai1200', 'Aici domneste Mihai1200', 5000000, 1, 0, 0, 8, 0, 0, 1, 4666, 1, 189123, 5, 20, 26000000),
(22, 1928.52, -1915.96, 15.2568, -42.5426, 1406.23, 1084.43, 'AdmBot', 'HQ BAWS', 5000000, 0, 0, 0, 8, 0, 0, 1, 5, 1, 218, 5, 21, 0),
(23, 2152.22, -1446.52, 26.1051, 2308.77, -1212.94, 1049.02, 'Blindatu', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 5000, 1, 115, 5, 22, 0),
(24, 2147.98, -1484.88, 26.6241, 235.228, 1187.86, 1080.26, 'WeiZe', 'STA Family !', 7000000, 1, 0, 1, 3, 1, 0, 1, 5000, 1, 455004, 5, 23, 0),
(25, 2149.85, -1433.68, 26.0703, 223.324, 1287.08, 1082.14, '=zeus=boss', 'Rent la casa 55!!', 5000000, 0, 0, 0, 1, 0, 0, 1, 1, 1, 78, 5, 24, 0),
(26, 1111.6, -976.003, 42.7656, 225.721, 1022.18, 1084.02, '[].FL0RiN', 'FL0RiN. admin 0', 10000000, 0, 0, 1, 7, 2, 0, 1, 1000, 1, 163025, 5, 25, 0),
(27, 2150.92, -1419.01, 25.9219, 2237.52, -1081.16, 1049.02, 'AdmBot', '```````', 5000000, 0, 0, 0, 2, 0, 0, 1, 5, 1, 21, 5, 26, 0),
(28, 2151.18, -1400.68, 26.1285, 2365.32, -1134.59, 1050.88, 'Marian97.', 'Casa Zeilor', 5000000, 1, 0, 0, 8, 0, 0, 1, 50, 1, 68911, 5, 27, 0),
(29, 315.85, -1769.75, 4.631, 2196, -1204.32, 1049.02, 'WiTTy..', 'HQ Clan [AIM] si Music On', 7000000, 1, 0, 1, 6, 1, 0, 1, 10, 1, 69519, 5, 28, 0),
(30, 295.251, -1764.12, 4.8701, 223.072, 1288.01, 1082.14, 'Cosmin.V3', 'Cosmin\'s residence! Helper 1', 5000000, 1, 0, 0, 1, 0, 0, 1, 1, 1, 117, 5, 29, 0),
(31, 946.289, -710.712, 122.62, 223.021, 1287.73, 1082.14, 'DjZeusGG', 'Aici domneste aweeL', 5000000, 0, 0, 0, 1, 0, 0, 1, 69, 1, 156410, 5, 30, 0),
(32, 1331.87, -632.87, 109.135, 2237.59, -1081.64, 1049.02, 'Skunk', 'House', 7000000, 1, 0, 0, 2, 1, 0, 1, 5000, 1, 755000, 5, 31, 0),
(33, 300.255, -1154.46, 81.391, 140.075, 1367.21, 1083.86, 'Sko0L.', 'The Legends !!', 10000000, 1, 0, 1, 5, 2, 0, 1, 5, 1, 1465, 15, 32, 0),
(34, 977.377, -770.917, 112.203, -42.5781, 1405.96, 1084.43, 'AdmBot', 'Dati rent la BO$$', 5000000, 0, 0, 0, 8, 0, 0, 1, 5, 1, 17075, 5, 33, 0),
(35, 897.94, -677.092, 116.89, 295.14, 1472.26, 1080.26, 'PoZiTiW3', 'PoZiTiW3 Residence\'', 7000000, 1, 0, 0, 15, 1, 0, 1, 5000, 1, 25030, 5, 34, 0),
(36, 891.252, -783.131, 101.314, 2324.53, -1149.54, 1050.71, 'xGarf', 'xGarf residence', 10000000, 1, 0, 0, 12, 2, 0, 1, 5, 1, 388, 5, 35, 0),
(37, 952.289, -909.99, 45.7656, 234.166, 1064.05, 1084.21, 'TheLike', 'Daoar faraonii au acces!', 10000000, 1, 0, 0, 6, 2, 1, 1, 69, 1, 8901, 5, 36, 0),
(38, 1440.59, -926.542, 39.641, 83.03, 1322.28, 1083.87, 'Dani.mocanu', 'Dani.mocanu e pe val din nou', 7000000, 0, 0, 0, 9, 1, 0, 1, 5, 1, 225, 5, 37, 0),
(39, 1981.84, -1682.86, 17.0538, 83.0945, 1322.78, 1083.87, 'Steven.', 'Casa De MAGNATI!', 7000000, 1, 0, 1, 9, 1, 0, 1, 5000, 1, 230116, 5, 38, 0),
(40, 2015.35, -1732.58, 14.2344, 223.2, 1287.08, 1082.14, 'Braken', 'Braken este REGE!', 5000000, 1, 0, 0, 1, 0, 0, 1, 1, 1, 2758, 5, 39, 0),
(41, 1298.53, -798.796, 84.1406, 234.19, 1063.73, 1084.21, 'Andreiii17e', 'Wi fi si muzica', 10000000, 1, 0, 1, 6, 2, 0, 1, 1, 1, 193, 5, 40, 0),
(42, 2393.2, -1646.26, 13.9051, 328.05, 1477.73, 1084.44, 'AdmBot', 'xKydux Gaboru\'', 5000000, 0, 0, 1, 15, 0, 0, 1, 5, 1, 305004, 5, 41, 0),
(43, 2409.12, -1674.94, 14.375, 2283.04, -1140.28, 1050.9, 'MAS', 'No strees, no limit ! King of', 5000000, 0, 0, 1, 11, 0, 0, 1, 5, 1, 50, 5, 42, 0),
(44, 2362.77, -1643.74, 14.0649, 223.2, 1287.08, 1082.14, 'TeroristuXXX', 'Casa barosanilor <3', 5000000, 0, 0, 0, 1, 0, 0, 1, 69, 1, 3911, 5, 43, 0),
(45, 254.887, -1366.69, 53.1094, 234.19, 1063.73, 1084.21, 'XSPEED0', 'SAL', 10000000, 0, 0, 1, 6, 2, 0, 1, 5000, 1, 460130, 5, 44, 0),
(46, 189.638, -1308.32, 70.2492, 225.68, 1021.45, 1084.02, 'Bahoi', 'LORD BAHOI [/call 6000]', 10000000, 1, 0, 1, 7, 2, 0, 1, 69, 1, 67361, 5, 45, 0),
(47, 251.765, -1220.67, 75.9508, 140.17, 1366.07, 1083.86, 'Veer', 'LVPD ', 100, 1, 0, 0, 5, 2, 0, 1, 5000, 1, 485420, 5, 46, 0),
(48, 416.651, -1154.24, 76.6876, 491.07, 1398.5, 1080.26, 'GlazKo', 'Welcome to Saint Tropez!', 7000000, 1, 0, 0, 2, 1, 1, 1, 0, 0, 95, 5, 47, 0),
(49, 2384.6, -1675.31, 14.9152, 260.85, 1237.24, 1084.26, 'DeNNis', 'HQ CLAN RED FAMILY', 5000000, 1, 0, 1, 9, 0, 0, 1, 1269, 1, 126940, 5, 48, 0),
(50, 2368.22, -1675.34, 14.1682, 260.85, 1237.24, 1084.26, 'LeOn', '.BAWS e cel mai tare clan.', 5000000, 0, 0, 0, 9, 0, 0, 1, 5, 1, 105, 5, 49, 0),
(51, 1442.69, -629.352, 95.7186, 24.04, 1340.17, 1084.38, 'Marga', 'Frectie la picior de lemn', 7000000, 1, 0, 0, 10, 1, 0, 1, 1, 1, 164, 5, 50, 0),
(52, 253.206, -1270, 74.4307, 140.075, 1367.21, 1083.86, 'ZeR0', 'VIP HOUSE', 10000000, 1, 0, 0, 5, 2, 0, 1, 1000, 1, 44025, 5, 51, 0),
(53, 745.107, -556.784, 18.013, 234.19, 1063.73, 1084.21, 'SteelBull', 'HQ G@DS!', 10000000, 1, 0, 1, 6, 2, 0, 1, 69, 1, 15854, 0, 52, 0),
(54, 2016.2, -1716.98, 14.125, 2308.77, -1212.94, 1049.02, 'ScoobyDoo', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 1, 1, 14, 5, 53, 0),
(55, 2018.24, -1703.23, 14.2344, -42.59, 1405.47, 1084.43, 'R3M1X', 'P0WER LIFE HQ', 5000000, 1, 0, 0, 8, 0, 0, 1, 5000, 1, 585090, 5, 54, 0),
(56, 2013.58, -1656.3, 14.1363, 328.05, 1477.73, 1084.44, 'panzani', 'Panzani\'s home', 5000000, 0, 0, 0, 15, 0, 0, 1, 5000, 1, 13710, 5, 55, 0),
(57, 2016.54, -1641.64, 14.1129, 2283.04, -1140.28, 1050.9, 'Teroristu', 'Terorisul sefu banilor.', 5000000, 1, 0, 0, 11, 0, 0, 1, 5000, 1, 41020, 5, 56, 0),
(58, 471.069, -1164.3, 67.1984, 2317.85, -1026.36, 1050.22, 'FuNNkyz0r[]', 'FuNNkyz0r[] LVPD', 7000000, 1, 0, 0, 9, 1, 0, 1, 5000, 1, 130230, 5, 57, 0),
(59, 281.054, -1768.5, 4.5229, 223.2, 1287.08, 1082.14, 'InMemoryOfPaulWalker', 'HQ  Alliance  [A]', 5000000, 1, 0, 1, 1, 0, 0, 1, 1, 1, 68, 5, 58, 0),
(60, 2018.05, -1629.95, 14.0426, 223.2, 1287.08, 1082.14, 'Catalin_112', 'Fortza BigZone 1000/1000.', 5000000, 1, 0, 0, 1, 0, 0, 1, 5000, 1, 5105, 5, 59, 0),
(61, 1051.03, -1058.68, 34.7966, 2259.38, -1135.77, 1050.64, 'Damien.', 'Casa De Bastanii!!!!', 5000000, 1, 0, 1, 10, 0, 0, 1, 5000, 1, 65000, 5, 60, 0),
(62, 219.756, -1250.46, 78.3323, 2324.53, -1149.54, 1050.71, 'Betty14', 'Party <3', 10000000, 1, 0, 1, 12, 2, 0, 1, 5, 1, 460, 5, 61, 0),
(63, 699.385, -1059.7, 49.4217, 2196.85, -1204.25, 1049.02, 'Evelin', 'HQ Clan .SiLENT', 7000000, 0, 0, 0, 6, 1, 0, 1, 5, 1, 170, 5, 62, 0),
(64, 2065.69, -1703.49, 14.1484, 222.969, 1287.63, 1082.14, 'LukaZ', 'Gold House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 45, 5, 63, 0),
(65, 993.739, -1058.52, 33.6995, 2233.64, -1115.26, 1050.88, 'qM3nTOL', 'Casa Barosanilor :D', 5000000, 0, 0, 0, 5, 0, 0, 1, 1, 1, 455004, 5, 64, 1000000000),
(66, 2066.24, -1717.02, 14.1363, -42.59, 1405.47, 1084.43, 'JFM_YT', 'Schimb pe alta casa', 5000000, 0, 0, 0, 8, 0, 0, 1, 5000, 1, 120005, 5, 65, 0),
(67, 1411.24, -920.882, 38.4219, 140.325, 1366.66, 1083.86, 'FrozeN', 'HQ Clan .wG', 10000000, 1, 0, 0, 5, 2, 0, 1, 5000, 1, 48954, 5, 66, 0),
(68, 2067.05, -1731.6, 14.2066, 223.2, 1287.08, 1082.14, 'FaKeAccOuNT', 'Fake Account!', 5000000, 1, 0, 0, 1, 0, 0, 1, 5000, 1, 305155, 5, 67, 150000000),
(69, 2238.66, 1285.69, 10.8203, 226.3, 1114.24, 1080.99, 'Roby', 'RobyRoberto VIP', 10000000, 1, 0, 0, 5, 2, 0, 1, 5000, 1, 195070, 5, 68, 300000000),
(70, 1846.29, 661.361, 11.4609, -42.59, 1405.47, 1084.43, 'LuKSs', 'Stiles\'s Niggas', 5000000, 0, 0, 0, 8, 0, 0, 1, 1, 1, 5000, 5, 69, 0),
(71, 1845.44, 741.339, 11.4609, 2259.38, -1135.87, 1050.64, 'Tudor', 'Tupac\'s Gang', 5000000, 0, 0, 0, 10, 0, 0, 1, 5, 1, 525, 5, 70, 0),
(72, 1844, 718.717, 11.4683, 266.505, 305.029, 999.148, 'AdmBot', 'House', 5000000, 0, 0, 0, 2, 0, 0, 1, 5, 1, 0, 5, 71, 15000000),
(73, 1844.53, 690.411, 11.4531, 243.723, 304.995, 999.148, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 72, 15000000),
(74, 2014.04, 650.406, 11.4609, 2218.4, -1076.28, 1050.48, 'ZupZap', 'Casa lui Zup', 5000000, 0, 0, 0, 1, 0, 0, 1, 2000, 1, 0, 5, 74, 0),
(75, 2011.59, 695.189, 11.4609, 2233.74, -1115.26, 1050.88, 'AdmBot', 'House', 5000000, 0, 0, 0, 5, 0, 0, 1, 5, 1, 0, 5, 75, 15000000),
(76, 2065.69, 649.864, 11.4683, 2308.79, -1212.94, 1049.02, 'AdmBot', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 5, 1, 0, 5, 76, 15000000),
(77, 2069.06, 696.629, 11.4683, -42.7103, 1405.47, 1084.43, 'AdmBot', 'House', 5000000, 0, 0, 0, 8, 0, 0, 1, 5, 1, 0, 5, 77, 15000000),
(78, 2120.38, 696.093, 11.4531, 223.071, 1287.08, 1082.14, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 78, 15000000),
(79, 2123.25, 651.313, 11.4609, 327.91, 1477.73, 1084.44, 'AdmBot', 'House', 5000000, 0, 0, 0, 15, 0, 0, 1, 5, 1, 0, 5, 79, 15000000),
(80, 2122.46, 731.351, 11.4609, 2282.83, -1140.27, 1050.9, 'AdmBot', 'House', 5000000, 0, 0, 0, 11, 0, 0, 1, 5, 1, 0, 5, 80, 15000000),
(81, 2123.39, 776.102, 11.4453, 223.022, 1287.08, 1082.14, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 81, 15000000),
(82, 2065.09, 729.824, 11.4683, 2259.38, -1135.87, 1050.64, 'AdmBot', 'House', 5000000, 0, 0, 0, 10, 0, 0, 1, 5, 1, 0, 5, 82, 15000000),
(83, 2071.61, 776.634, 11.4605, 243.723, 304.995, 999.148, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 83, 15000000),
(84, 2013.24, 730.358, 11.4531, 266.505, 305.029, 999.148, 'FlorinZew', 'House', 5000000, 0, 0, 0, 2, 0, 0, 1, 5, 1, 0, 5, 84, 0),
(85, 2014.09, 774.998, 11.4609, 2218.4, -1076.28, 1050.48, 'Adi', 'V.I.P House.', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 30, 5, 85, 0),
(86, 2169.18, 772.292, 11.4609, 2233.74, -1115.26, 1050.88, 'AdmBot', 'House', 5000000, 0, 0, 0, 5, 0, 0, 1, 5, 1, 0, 5, 86, 15000000),
(87, 2177.24, 690.472, 11.4609, 2308.77, -1212.94, 1049.02, 'AdmBot', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 5, 1, 10, 5, 87, 15000000),
(88, 2177.67, 736.103, 11.4609, -42.7103, 1405.47, 1084.43, 'Donboo', 'Scuze DJ_Yonutz.', 5000000, 0, 0, 0, 8, 0, 0, 1, 5, 1, 25, 5, 88, 0),
(89, 2228.59, 689.811, 11.4605, 223.071, 1287.08, 1082.14, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 285, 5, 89, 15000000),
(90, 2228.34, 734.983, 11.4609, 327.91, 1477.73, 1084.44, 'AdmBot', 'House', 5000000, 0, 0, 0, 15, 0, 0, 1, 5, 1, 10, 5, 90, 15000000),
(91, 2317.16, 690.351, 11.4609, 2282.83, -1140.27, 1050.9, 'AdmBot', 'House', 5000000, 0, 0, 0, 11, 0, 0, 1, 5, 1, 0, 5, 91, 15000000),
(92, 2368.59, 689.8, 11.4605, 223.022, 1287.08, 1082.14, 'AdmBot', 'Horica !', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 12030, 5, 92, 20000000),
(93, 2369.18, 735.197, 11.4609, 2259.38, -1135.87, 1050.64, 'AdmBot', 'House', 5000000, 0, 0, 0, 10, 0, 0, 1, 5, 1, 0, 5, 93, 15000000),
(94, 2450.27, 742.661, 11.4609, 243.723, 304.995, 999.148, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 94, 15000000),
(95, 2449.23, 689.898, 11.4609, 266.505, 305.029, 999.148, 'AdmBot', 'House', 5000000, 0, 0, 0, 2, 0, 0, 1, 5, 1, 0, 5, 95, 15000000),
(96, 2178.11, 655.993, 11.4609, 2218.4, -1076.28, 1050.48, 'AdmBot', 'House', 5000000, 0, 0, 0, 1, 0, 0, 1, 5, 1, 0, 5, 96, 15000000),
(97, 2228.88, 655.003, 11.4609, 2233.74, -1115.26, 1050.88, 'AdmBot', 'House', 5000000, 0, 0, 0, 5, 0, 0, 1, 5, 1, 0, 5, 97, 15000000),
(98, 2317.92, 656.101, 11.4531, 2308.77, -1212.94, 1049.02, 'AdmBot', 'House', 5000000, 0, 0, 0, 6, 0, 0, 1, 5, 1, 0, 5, 98, 15000000),
(99, 743.308, -509.318, 18.013, -42.7103, 1405.47, 1084.43, 'AdmBot', 'BigZone', 2000000, 0, 0, 0, 8, 0, 0, 1, 5, 1, 400000, 5, 99, 0),
(100, 2301.86, 1285.74, 67.4688, 234.282, 1063.72, 1084.21, 'ZerG.INVALUiRE', '#CASA#DE#MAGNATI#', 10000000, 1, 0, 1, 6, 2, 0, 1, 5000, 1, 695000, 5, 100, 0),
(101, 1451.08, -2286.71, 13.547, 225.68, 1021.45, 1084.02, 'NoXe', 'Seraphim Family', 10000000, 1, 0, 1, 7, 2, 0, 1, 5000, 1, 1450365, 5, 101, 0),
(102, 2306.91, -1678.63, 14.001, 967.735, -53.186, 1001.12, 'CraZ[z]Zy', 'BORDEIUL PUILOR GREI', 1000000, 1, 0, 1, 3, 0, 0, 1, 69, 1, 1173, 1, 0, 0),
(103, 870.336, -25.113, 63.973, 2468.27, -1698.31, 1013.51, 'Samuray', 'CATALINU DE DIMINEATA', 1, 1, 0, 0, 2, 0, 0, 1, 1, 1, 15010, 10, 0, 0),
(104, 298.576, -1338.01, 53.442, 140.17, 1366.07, 1083.86, 'AdmBot', 'House', 15000000, 1, 0, 0, 5, 2, 0, 1, 5, 1, 672, 10, 104, 0),
(105, 1122.98, -2037.02, 69.894, 2544.7, -1305.07, 1054.64, 'piMp', 'Rich Residence', 10000000, 0, 0, 0, 2, 0, 0, 1, 5000, 1, 2925000, 10, 105, 0);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `jobName` varchar(30) NOT NULL,
  `times` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `jobs`
--

INSERT INTO `jobs` (`id`, `jobName`, `times`) VALUES
(5, 'Pizza Boy', 'PizzaTimes'),
(6, 'Farmer', 'FarmTimes'),
(7, 'Bus Driver', 'BusTimes'),
(9, 'Arms Dealer', 'ArmsTimes'),
(13, 'Fisher', 'FishTimes'),
(14, 'Trucker', 'TruckTimes');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `kicklogs`
--

CREATE TABLE `kicklogs` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `playername` varchar(30) NOT NULL,
  `givername` varchar(30) NOT NULL,
  `reason` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `kill_logs`
--

CREATE TABLE `kill_logs` (
  `ID` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `killerid` int(11) NOT NULL,
  `playername` varchar(30) NOT NULL,
  `killername` varchar(30) NOT NULL,
  `reason` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `lastfreports`
--

CREATE TABLE `lastfreports` (
  `id` int(11) NOT NULL,
  `idd` varchar(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `Raport1` int(11) NOT NULL,
  `Raport2` int(11) NOT NULL,
  `Raport3` int(11) NOT NULL,
  `Raport4` int(11) NOT NULL,
  `Raport5` int(11) NOT NULL,
  `Raport6` int(11) NOT NULL,
  `Raport7` int(11) NOT NULL,
  `faction` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `log` varchar(256) NOT NULL,
  `where` varchar(20) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `log_admin`
--

CREATE TABLE `log_admin` (
  `id` int(11) NOT NULL,
  `log` varchar(256) NOT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `namechanges`
--

CREATE TABLE `namechanges` (
  `namechangeid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `oldname` varchar(30) NOT NULL,
  `newname` varchar(30) NOT NULL,
  `adminid` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `newbie_logs`
--

CREATE TABLE `newbie_logs` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `question` varchar(128) NOT NULL,
  `answer` varchar(128) NOT NULL,
  `time` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `objects_accesory`
--

CREATE TABLE `objects_accesory` (
  `ID` int(11) NOT NULL,
  `Model` int(11) NOT NULL,
  `Type` int(11) NOT NULL DEFAULT 5,
  `Money` int(11) NOT NULL DEFAULT 15000,
  `Premium` int(11) NOT NULL,
  `Bone` int(11) NOT NULL DEFAULT 2,
  `fOffsetX` float NOT NULL DEFAULT 0.162424,
  `fOffsetY` float NOT NULL DEFAULT 0.021068,
  `fOffsetZ` float NOT NULL DEFAULT 0.011462,
  `fRotX` float NOT NULL DEFAULT 272.137,
  `fRotY` float NOT NULL DEFAULT 348.285,
  `fRotZ` float NOT NULL DEFAULT 270.647
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `objects_accesory`
--

INSERT INTO `objects_accesory` (`ID`, `Model`, `Type`, `Money`, `Premium`, `Bone`, `fOffsetX`, `fOffsetY`, `fOffsetZ`, `fRotX`, `fRotY`, `fRotZ`) VALUES
(1, 18947, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(2, 18948, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(3, 18945, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(4, 18949, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(5, 18950, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(6, 18951, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(7, 18941, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(8, 18942, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(9, 18943, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(10, 19095, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(11, 18962, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(12, 19097, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(13, 19096, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(14, 18934, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(15, 18969, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(16, 18945, 0, 60000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(17, 18962, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(18, 19098, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(19, 19096, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(20, 18935, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(21, 18934, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(22, 19488, 0, 50000, 0, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(23, 18931, 0, 0, 20, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(24, 19487, 0, 0, 20, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(25, 19558, 0, 0, 20, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(26, 19160, 0, 0, 20, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(27, 19098, 0, 0, 20, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(28, 19528, 0, 0, 50, 2, 0.169287, 0.002255, -0.002116, 0, 0, 0),
(29, 19006, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(30, 19008, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(31, 19007, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(32, 19009, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(33, 19010, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(34, 19011, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(35, 19012, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(36, 19018, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(37, 19013, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(38, 19014, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(39, 19015, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(40, 19016, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(41, 19017, 1, 50000, 0, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(42, 19019, 1, 0, 10, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(43, 19020, 1, 0, 10, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(44, 19021, 1, 0, 10, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(45, 19022, 1, 0, 10, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(46, 19023, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(47, 19024, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(48, 19025, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(49, 19026, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(50, 19027, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(51, 19028, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(52, 19029, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(53, 19030, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(54, 19031, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(55, 19032, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(56, 19033, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(57, 19034, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(58, 19035, 1, 0, 15, 2, 0.079939, 0.020731, -0.005162, 89.6755, 83.5503, 0),
(59, 19039, 2, 0, 30, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(60, 19042, 2, 0, 30, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(61, 19053, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(62, 19052, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(63, 19051, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(64, 19050, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(65, 19049, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(66, 19048, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(67, 19047, 2, 15000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(68, 19046, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(69, 19045, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(70, 19044, 2, 50000, 0, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(71, 19043, 2, 0, 30, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(72, 19041, 2, 0, 30, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(73, 19040, 2, 0, 30, 5, -0.025012, -0.002121, 0.012567, 206.874, 247.756, 9.74427),
(74, 19081, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(75, 19084, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(76, 18643, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(77, 19080, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(78, 19082, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(79, 19083, 3, 0, 100, 6, 0.096126, 0.008285, 0, 126.63, 88.235, 52.2948),
(80, 2404, 4, 0, 50, 5, -0.023777, 0.060493, 0.036487, 0, 0, 0),
(81, 18637, 4, 0, 100, 3, 0.372591, -0.2732, -0.035485, 0, 5.66619, 95.4819),
(82, 18632, 4, 500000, 20, 6, 0.08081, 0.038068, 0, 192.926, 9.6064, 0),
(83, 1210, 4, 0, 50, 5, 0.326087, 0.085488, 0, 0, 266.01, 0),
(84, 19878, 4, 0, 100, 5, 0.012479, 0.10195, 0.029353, 114.236, 356.216, 93.6255),
(85, 2704, 4, 15000, 0, 6, 0.446643, 0, -0.029046, 0, 275.05, 0),
(86, 19038, 5, 100000, 0, 2, 0.106539, 0.034585, 0.001571, 0, 84.578, 91.2186),
(87, 19036, 5, 100000, 0, 2, 0.106539, 0.034585, 0.001571, 0, 84.578, 91.2186),
(88, 19037, 5, 100000, 0, 2, 0.106539, 0.034585, 0.001571, 0, 84.578, 91.2186),
(89, 18919, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(90, 18912, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(91, 18913, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(92, 18914, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(93, 18915, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(94, 18916, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(95, 18917, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(96, 18918, 5, 100000, 0, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(97, 18920, 5, 0, 20, 2, 0.162424, 0.021068, 0.011462, 272.137, 348.285, 270.647),
(98, 19317, 6, 0, 150, 1, 0.127579, -0.115369, 0, 355.117, 105.806, 352.232),
(99, 19318, 6, 0, 200, 1, 0.127579, -0.115369, 0, 355.117, 105.806, 352.232),
(100, 19079, 7, 0, 250, 1, 0.387458, -0.061525, -0.176822, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `olderfreports`
--

CREATE TABLE `olderfreports` (
  `id` int(11) NOT NULL,
  `day` varchar(3) NOT NULL,
  `month` varchar(3) NOT NULL,
  `year` varchar(4) NOT NULL,
  `hour` varchar(5) NOT NULL,
  `faction` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `panelactions`
--

CREATE TABLE `panelactions` (
  `id` int(11) NOT NULL,
  `actionid` int(11) NOT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `complaintid` int(11) NOT NULL DEFAULT 0,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `playername` varchar(64) NOT NULL,
  `givername` varchar(64) NOT NULL,
  `reason` varchar(128) NOT NULL,
  `dm` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `panelactions2`
--

CREATE TABLE `panelactions2` (
  `id` int(11) NOT NULL,
  `actionid` int(11) NOT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `complaintid` int(11) NOT NULL DEFAULT 0,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `playername` varchar(64) NOT NULL,
  `givername` varchar(64) NOT NULL,
  `reason` varchar(128) NOT NULL,
  `dm` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `panel_chat`
--

CREATE TABLE `panel_chat` (
  `ID` int(11) NOT NULL,
  `SentBy` varchar(256) NOT NULL,
  `Text` varchar(256) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `panel_restrict`
--

CREATE TABLE `panel_restrict` (
  `ID` int(11) NOT NULL,
  `PlayerName` varchar(20) NOT NULL,
  `AdminName` varchar(20) NOT NULL,
  `Reason` text NOT NULL,
  `Time` int(15) NOT NULL,
  `Days` int(11) NOT NULL,
  `Permanent` int(11) NOT NULL,
  `BanTimeDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `playerconnections`
--

CREATE TABLE `playerconnections` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `ip` varchar(16) NOT NULL,
  `gpci` varchar(128) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `playerlogs`
--

CREATE TABLE `playerlogs` (
  `ID` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `action` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `player_accessory`
--

CREATE TABLE `player_accessory` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Accessory` varchar(64) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0',
  `Bone` varchar(32) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0',
  `Status` varchar(64) NOT NULL DEFAULT '0|0|0|0|0|0|0|0|0|0',
  `Index0` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index1` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index2` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index3` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index4` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index5` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index6` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index7` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index8` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0',
  `Index9` varchar(64) NOT NULL DEFAULT '0.0|0.0|0.0|0.0|0.0|0.0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `punishlogs`
--

CREATE TABLE `punishlogs` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `playername` varchar(30) NOT NULL,
  `givername` varchar(30) NOT NULL,
  `complaintid` int(11) NOT NULL DEFAULT 0,
  `actionid` int(11) NOT NULL,
  `actiontime` int(11) NOT NULL DEFAULT 0,
  `reason` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `unixtime` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `recover`
--

CREATE TABLE `recover` (
  `RecoverKey` varchar(255) NOT NULL DEFAULT '',
  `name` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `reply_complaints`
--

CREATE TABLE `reply_complaints` (
  `id` int(11) NOT NULL,
  `idd` int(11) NOT NULL,
  `user` varchar(30) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `edited` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `time` varchar(20) NOT NULL,
  `unixtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `reply_requests`
--

CREATE TABLE `reply_requests` (
  `id` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `tip` int(11) NOT NULL,
  `user` text NOT NULL,
  `data` text NOT NULL,
  `status` int(11) NOT NULL,
  `idd` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `unixtime` varchar(20) NOT NULL,
  `deleted` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `reply_tickets`
--

CREATE TABLE `reply_tickets` (
  `id` int(11) NOT NULL,
  `idd` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `time` varchar(50) NOT NULL,
  `edited` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `unixtime` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `report_logs`
--

CREATE TABLE `report_logs` (
  `id` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `problem` varchar(128) NOT NULL,
  `answer` varchar(128) NOT NULL,
  `time` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `session_data`
--

CREATE TABLE `session_data` (
  `id` int(11) NOT NULL,
  `usr` int(11) NOT NULL,
  `data` text DEFAULT NULL,
  `ip` varchar(20) NOT NULL,
  `unixtime` int(16) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `shop_logs`
--

CREATE TABLE `shop_logs` (
  `id` int(11) NOT NULL,
  `Message` varchar(128) NOT NULL,
  `playerid` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `staff_logs`
--

CREATE TABLE `staff_logs` (
  `ID` int(11) NOT NULL,
  `text` varchar(128) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `stock`
--

CREATE TABLE `stock` (
  `ID` int(11) NOT NULL,
  `Stock` int(11) NOT NULL,
  `Price` int(20) NOT NULL,
  `Car` varchar(50) NOT NULL,
  `vid` int(11) NOT NULL,
  `speed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `stock`
--

INSERT INTO `stock` (`ID`, `Stock`, `Price`, `Car`, `vid`, `speed`) VALUES
(0, 30, 250000, 'Bike', 509, 93),
(1, 29, 500000, 'Faggio', 462, 99),
(2, 27, 700000, 'BMX', 481, 86),
(3, 26, 800000, 'Benson', 499, 109),
(4, 24, 850000, 'Perennial', 404, 118),
(5, 18, 900000, 'Picador', 600, 134),
(6, 17, 900000, 'Pony', 413, 98),
(7, 10, 950000, 'Rumpo', 440, 121),
(8, 9, 1000000, 'Mountain Bike', 510, 114),
(9, 8, 1000000, 'Moonbeam', 418, 102),
(10, 6, 1000000, 'Camper', 483, 109),
(11, 5, 1100000, 'Sadler', 543, 134),
(12, 25, 1100000, 'Walton', 478, 104),
(13, 24, 1200000, 'Regina', 479, 124),
(14, 23, 1300000, 'Bravura', 401, 130),
(15, 22, 1400000, 'Oceanic', 467, 125),
(16, 21, 1400000, 'Glendale', 466, 130),
(17, 29, 1450000, 'Willard', 529, 132),
(18, 28, 1500000, 'Hermes', 474, 132),
(19, 27, 1700000, 'Manana', 410, 115),
(20, 26, 1700000, 'Quad', 471, 98),
(21, 24, 1800000, 'Intruder', 546, 132),
(22, 23, 1900000, 'Berkley\'s RC Van', 459, 121),
(23, 23, 2000000, 'Previon', 436, 132),
(24, 22, 2000000, 'Primo', 547, 127),
(25, 21, 2000000, 'Fortune', 526, 140),
(26, 27, 2100000, 'Virgo', 491, 132),
(27, 28, 2100000, 'Majestic', 517, 140),
(28, 26, 2200000, 'Bobcat', 422, 124),
(29, 24, 2200000, 'Cadrona', 527, 132),
(30, 23, 2300000, 'Sunrise', 550, 128),
(31, 22, 2500000, 'Burrito', 482, 139),
(32, 20, 2500000, 'Solair', 458, 140),
(33, 18, 2600000, 'Mesa', 500, 125),
(34, 18, 2700000, 'Journey', 508, 96),
(35, 22, 2800000, 'Merit', 551, 140),
(36, 26, 2800000, 'Emperor', 585, 136),
(37, 25, 3000000, 'Landstalker', 400, 140),
(38, 24, 3100000, 'Nebula', 516, 140),
(39, 27, 3300000, 'Esperanto', 419, 132),
(40, 26, 3400000, 'Stallion', 439, 150),
(41, 25, 3400000, 'Stafford', 580, 136),
(42, 24, 3400000, 'Clover', 542, 146),
(43, 22, 3500000, 'Tampa', 549, 136),
(44, 22, 4000000, 'Blista Compact', 496, 144),
(45, 25, 4000000, 'Greenwood', 492, 125),
(46, 27, 4000000, 'Hotknife', 434, 148),
(47, 26, 4000000, 'Hustler', 545, 130),
(48, 25, 4100000, 'Vincent', 540, 132),
(49, 23, 4200000, 'Stratum', 561, 137),
(50, 22, 4250000, 'Elegant', 507, 147),
(51, 21, 4300000, 'Washington', 421, 136),
(52, 20, 4500000, 'Broadway', 575, 140),
(53, 19, 4700000, 'Tahoma', 566, 142),
(54, 29, 4700000, 'Savanna', 567, 153),
(55, 28, 5000000, 'Tornado', 576, 140),
(56, 27, 5000000, 'Slamvan', 535, 140),
(57, 26, 5000000, 'Buccaneer', 518, 146),
(58, 25, 5200000, 'Yosemite', 554, 128),
(59, 24, 5300000, 'Windsor', 555, 140),
(60, 29, 5700000, 'Remington', 534, 150),
(61, 28, 5900000, 'Wayfarer', 586, 127),
(62, 26, 6000000, 'Bloodring Banger', 504, 153),
(63, 25, 6200000, 'Premier', 426, 154),
(64, 24, 6500000, 'Club', 589, 144),
(65, 22, 6700000, 'Phoenix', 603, 152),
(66, 21, 6700000, 'Rancher', 489, 124),
(67, 19, 6700000, 'Freeway', 463, 130),
(68, 18, 6700000, 'Sabre', 475, 153),
(69, 18, 6900000, 'Blade', 536, 153),
(70, 17, 7000000, 'Sentinel', 405, 145),
(71, 15, 7000000, 'Feltzer', 533, 148),
(72, 14, 7000000, 'Euros', 587, 146),
(73, 12, 7000000, 'Admiral', 445, 145),
(74, 11, 7500000, 'Voodoo', 412, 150),
(75, 16, 7700000, 'Sanchez', 468, 128),
(76, 21, 8000000, 'Alpha', 602, 150),
(77, 24, 9000000, 'Flash', 565, 146),
(78, 23, 9000000, 'Uranus', 558, 138),
(79, 22, 9000000, 'Huntley', 579, 140),
(80, 21, 12000000, 'Comet', 480, 163),
(81, 18, 13000000, 'BF-400', 581, 134),
(82, 18, 14000000, 'Super GT', 506, 159),
(83, 17, 16000000, 'PCJ-600', 461, 143),
(84, 15, 18000000, 'FCR-900', 521, 141),
(85, 8, 19000000, 'ZR-350', 477, 165),
(86, 9, 20000000, 'Jester', 559, 158),
(87, 8, 21000000, 'Buffalo', 402, 165),
(88, 6, 22000000, 'Sandking', 495, 156),
(89, 5, 23000000, 'Elegy', 562, 158),
(90, 2, 25000000, 'Cheetah', 415, 171),
(91, 4, 27000000, 'Banshee', 429, 179),
(92, 3, 35000000, 'Turismo', 451, 172),
(93, 2, 40000000, 'Sultan', 560, 150),
(94, 1, 45000000, 'Bullet', 541, 180),
(95, 0, 60000000, 'NRG-500', 522, 156),
(96, 2, 80000000, 'Infernus', 411, 197),
(97, 0, 100000000, 'Sparrow', 469, 77),
(98, 10000, 100000000, 'Hotring Racer B', 503, 191),
(99, 10000, 100000000, 'Hotring Racer A', 502, 191),
(100, 10000, 100000000, 'Vortex', 539, 88),
(101, 10000, 100000000, 'Hotring Racer', 494, 191),
(102, 10000, 100000000, 'Maverick', 487, 150),
(103, 10000, 1, 'Stretch', 409, 140),
(104, 10000, 1, 'Monster', 444, 100);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `su_logs`
--

CREATE TABLE `su_logs` (
  `ID` int(11) NOT NULL,
  `playerid` int(11) NOT NULL,
  `giverid` int(11) NOT NULL,
  `reason` varchar(128) NOT NULL,
  `sumessage` varchar(256) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `svars`
--

CREATE TABLE `svars` (
  `id` int(11) NOT NULL,
  `SvarName` varchar(32) NOT NULL DEFAULT 'None',
  `SvarValue` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `svars`
--

INSERT INTO `svars` (`id`, `SvarName`, `SvarValue`) VALUES
(1, 'holidays_active', 0),
(2, 'job_bonus', 0);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `Name` int(11) NOT NULL,
  `Ticket` text NOT NULL,
  `Status` int(11) NOT NULL,
  `time` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  `deleted` int(11) NOT NULL,
  `unixtime` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `timeonline`
--

CREATE TABLE `timeonline` (
  `id` int(11) NOT NULL,
  `m` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `hoursplayed` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `timeplayed`
--

CREATE TABLE `timeplayed` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  `month` varchar(5) NOT NULL,
  `year` int(5) NOT NULL DEFAULT 0,
  `day` varchar(5) NOT NULL,
  `unixtime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `toph`
--

CREATE TABLE `toph` (
  `id` int(11) NOT NULL,
  `ponline` int(11) NOT NULL,
  `hour` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `turfs`
--

CREATE TABLE `turfs` (
  `ID` int(11) NOT NULL,
  `Owned` int(11) NOT NULL,
  `MinX` float NOT NULL,
  `MinY` float NOT NULL,
  `MaxX` float NOT NULL,
  `MaxY` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `turfs`
--

INSERT INTO `turfs` (`ID`, `Owned`, `MinX`, `MinY`, `MaxX`, `MaxY`) VALUES
(1, 6, 114.21, -1364.93, 506.54, -912.91),
(2, 5, 506.54, -1364.93, 899.25, -912.91),
(3, 6, 899.25, -1313.7, 1313.58, -912.91),
(4, 5, 1313.58, -1364.93, 1727.49, -912.91),
(5, 5, 1727.49, -1364.93, 2108.13, -912.91),
(6, 5, 2108.13, -1364.93, 2499.38, -912.91),
(7, 5, 2499.38, -1313.7, 2916.17, -912.91),
(8, 5, 114.21, -1821.03, 506.54, -1364.93),
(9, 5, 506.54, -1821.03, 899.25, -1364.93),
(10, 5, 899.25, -1721.9, 1313.58, -1313.7),
(11, 5, 1313.58, -1821.03, 1727.49, -1364.93),
(12, 5, 1727.49, -1821.03, 2108.13, -1364.93),
(13, 5, 2108.13, -1821.03, 2499.38, -1364.93),
(14, 5, 2499.38, -1737.65, 2916.17, -1313.7),
(15, 6, 899.25, -2131.32, 1313.58, -1721.9),
(16, 6, 899.25, -2489.99, 1313.58, -2131.32),
(17, 5, 1313.58, -2250.92, 1727.49, -1821.03),
(18, 5, 1727.49, -2250.92, 2108.13, -1821.03),
(19, 5, 2108.13, -2250.92, 2499.38, -1821.03),
(20, 5, 2499.38, -2172.41, 2916.17, -1737.65),
(21, 5, 1313.58, -2690.47, 1727.49, -2250.92),
(22, 5, 1727.49, -2690.47, 2108.13, -2250.92),
(23, 5, 2108.13, -2690.47, 2499.38, -2250.92),
(24, 5, 2499.38, -2567.91, 2916.17, -2172.41),
(25, 10, 1114.47, 2444.49, 1478.16, 2901.03),
(26, 4, 1478.16, 2444.49, 1828.16, 2901.03),
(27, 4, 2150.16, 2444.49, 2528.16, 2901.03),
(28, 4, 1828.16, 2444.49, 2150.16, 2901.03),
(29, 4, 2528.16, 2444.49, 2878.16, 2901.03),
(30, 4, 901.16, 1980.34, 1307.16, 2444.49),
(31, 4, 1307.16, 1980.34, 1677.16, 2444.49),
(32, 4, 1677.16, 1980.34, 2076.16, 2444.49),
(33, 4, 2076.16, 1980.34, 2482, 2444.49),
(34, 4, 2482, 1980.34, 2878.16, 2444.49),
(35, 10, 901.16, 1528.09, 1307.16, 1980.34),
(36, 4, 1307.16, 1528.09, 1677.16, 1980.34),
(37, 4, 1677.16, 1528.09, 2076.16, 1980.34),
(38, 4, 2076.16, 1528.09, 2482, 1980.34),
(39, 4, 2482, 1528.09, 2878.16, 1980.34),
(40, 10, 901.16, 1074.9, 1307.16, 1528.09),
(41, 10, 1307.16, 1074.9, 1677.16, 1528.09),
(42, 10, 1677.16, 1074.9, 2076.16, 1528.09),
(43, 4, 2076.16, 1074.9, 2482, 1528.09),
(44, 4, 2482, 1074.9, 2878.16, 1528.09),
(45, 10, 1307.16, 663.83, 1677.16, 1074.9),
(46, 10, 1677.16, 663.83, 2076.16, 1074.9),
(47, 10, 2076.16, 663.83, 2482, 1074.9),
(48, 10, 2482, 663.83, 2878.16, 1074.9);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `unban_requests`
--

CREATE TABLE `unban_requests` (
  `id` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `tip` int(11) NOT NULL,
  `user` text NOT NULL,
  `admin` text NOT NULL,
  `reason` text NOT NULL,
  `data` text NOT NULL,
  `status` int(11) NOT NULL,
  `idd` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `deleted` int(11) NOT NULL,
  `permanent` int(11) NOT NULL,
  `postedfromip` varchar(20) NOT NULL,
  `days` int(11) NOT NULL,
  `bantimedate` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_romanian_ci NOT NULL,
  `date` text NOT NULL,
  `byAdmin` text NOT NULL,
  `For` int(11) NOT NULL,
  `link` text NOT NULL,
  `title` varchar(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `password` varchar(129) NOT NULL,
  `Level` int(3) NOT NULL DEFAULT 1,
  `Admin` int(2) NOT NULL DEFAULT 0,
  `Helper` int(2) NOT NULL DEFAULT 0,
  `IP` varchar(20) NOT NULL DEFAULT '127.0.0.1',
  `Premium` int(2) NOT NULL DEFAULT 0,
  `Beta` int(2) NOT NULL DEFAULT 0,
  `Support` int(3) NOT NULL DEFAULT 0,
  `ConnectedTime` float NOT NULL DEFAULT 0,
  `Registered` int(2) NOT NULL DEFAULT 0,
  `Sex` int(2) NOT NULL DEFAULT 0,
  `Age` int(3) NOT NULL DEFAULT 0,
  `Origin` int(2) NOT NULL DEFAULT 1,
  `Muted` int(2) NOT NULL DEFAULT 0,
  `MuteTime` int(11) NOT NULL DEFAULT 0,
  `Respect` int(11) NOT NULL DEFAULT 0,
  `Money` int(30) NOT NULL DEFAULT 0,
  `Bank` int(30) NOT NULL DEFAULT 0,
  `Crimes` int(11) NOT NULL DEFAULT 0,
  `Kills` int(11) NOT NULL DEFAULT 0,
  `Deaths` int(11) NOT NULL DEFAULT 0,
  `Arrested` int(11) NOT NULL DEFAULT 0,
  `WantedDeaths` int(11) NOT NULL DEFAULT 0,
  `Phonebook` int(2) NOT NULL DEFAULT 0,
  `WantedLevel` int(11) NOT NULL DEFAULT 0,
  `Fishes` int(3) NOT NULL DEFAULT 0,
  `Job` int(3) NOT NULL DEFAULT 0,
  `Paycheck` int(11) NOT NULL DEFAULT 0,
  `HeadValue` int(11) NOT NULL DEFAULT 0,
  `Jailed` int(2) NOT NULL DEFAULT 0,
  `JailTime` int(11) NOT NULL DEFAULT 0,
  `dm` int(3) NOT NULL DEFAULT 0,
  `dmp` int(3) NOT NULL DEFAULT 0,
  `dmt` int(5) NOT NULL DEFAULT 0,
  `dmpt` int(5) NOT NULL DEFAULT 0,
  `Materials` int(11) NOT NULL DEFAULT 0,
  `Drugs` int(11) NOT NULL DEFAULT 0,
  `Leader` int(3) NOT NULL DEFAULT 0,
  `Member` int(3) NOT NULL DEFAULT 0,
  `Rank` int(2) NOT NULL DEFAULT 0,
  `FWarn` int(2) NOT NULL DEFAULT 0,
  `FPunish` int(4) NOT NULL DEFAULT 0,
  `pHealth` float NOT NULL DEFAULT 100,
  `Inter` int(3) NOT NULL DEFAULT 0,
  `Local` int(11) NOT NULL DEFAULT 0,
  `Team` int(3) NOT NULL DEFAULT 0,
  `Model` int(11) NOT NULL DEFAULT 250,
  `PhoneNr` int(5) NOT NULL DEFAULT 0,
  `PhoneCredits` int(4) NOT NULL DEFAULT 0,
  `House` int(11) NOT NULL DEFAULT 999,
  `Bizz` int(11) NOT NULL DEFAULT 255,
  `Pos_x` float NOT NULL DEFAULT 2000,
  `Pos_y` float NOT NULL DEFAULT 2000,
  `Pos_z` float NOT NULL DEFAULT 2000,
  `Rob` int(11) NOT NULL DEFAULT 0,
  `GunLicSuspend` int(3) NOT NULL DEFAULT 0,
  `CarLicSuspend` int(3) NOT NULL DEFAULT 0,
  `CarLicT` int(11) NOT NULL DEFAULT 0,
  `CarLic` int(2) NOT NULL DEFAULT 0,
  `FlyLicT` int(11) NOT NULL DEFAULT 0,
  `FlyLic` int(2) NOT NULL DEFAULT 0,
  `BoatLicT` int(11) NOT NULL DEFAULT 0,
  `BoatLic` int(2) NOT NULL DEFAULT 0,
  `FishLicT` int(11) NOT NULL DEFAULT 0,
  `FishLic` int(2) NOT NULL DEFAULT 0,
  `GunLicT` int(11) NOT NULL DEFAULT 0,
  `GunLic` int(2) NOT NULL DEFAULT 0,
  `PayDay` int(20) NOT NULL DEFAULT 0,
  `PayDayHad` int(20) NOT NULL DEFAULT 0,
  `Tutorial` int(2) NOT NULL DEFAULT 0,
  `Warnings` int(2) NOT NULL DEFAULT 0,
  `Rented` int(111) NOT NULL DEFAULT 0,
  `Fuel` int(11) NOT NULL DEFAULT 0,
  `WTalkie` int(2) NOT NULL DEFAULT 0,
  `Tow` int(20) NOT NULL DEFAULT 0,
  `Email` varchar(50) NOT NULL DEFAULT 'email@yahoo.com',
  `RegisterDate` varchar(50) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastOn` varchar(50) NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Victim` varchar(64) NOT NULL,
  `Status` int(11) NOT NULL DEFAULT 0,
  `HitT` int(20) NOT NULL DEFAULT 0,
  `Phone` int(11) NOT NULL DEFAULT 0,
  `Accused` varchar(64) NOT NULL DEFAULT '********',
  `Crime1` varchar(184) NOT NULL DEFAULT 'Fara',
  `Crime2` varchar(184) NOT NULL DEFAULT 'Fara',
  `Crime3` varchar(184) NOT NULL DEFAULT 'Fara',
  `Fakea` int(11) NOT NULL DEFAULT 0,
  `HPoints` int(11) NOT NULL DEFAULT 0,
  `Language` int(2) NOT NULL DEFAULT 0,
  `rpgon` int(11) NOT NULL DEFAULT 0,
  `PremiumPoints` int(11) NOT NULL DEFAULT 0,
  `PawnPoints` int(11) NOT NULL DEFAULT 0,
  `FWorks` int(11) NOT NULL DEFAULT 0,
  `VirtualPD` int(11) NOT NULL DEFAULT 0,
  `Glasses` int(11) NOT NULL DEFAULT 0,
  `Hats` int(11) NOT NULL DEFAULT 0,
  `GiftBoxTime` int(11) NOT NULL DEFAULT 0,
  `SpawnChange` int(11) NOT NULL DEFAULT 0,
  `RobSkill` int(11) NOT NULL DEFAULT 1,
  `RobTimes` int(11) NOT NULL DEFAULT 0,
  `RobRem` int(11) NOT NULL DEFAULT 26,
  `FishSkill` int(11) NOT NULL DEFAULT 1,
  `FishTimes` int(11) NOT NULL DEFAULT 0,
  `FishRem` int(11) NOT NULL DEFAULT 26,
  `TruckSkill` int(11) NOT NULL DEFAULT 1,
  `TruckTimes` int(11) NOT NULL DEFAULT 0,
  `TruckRem` int(11) NOT NULL DEFAULT 26,
  `FarmSkill` int(11) NOT NULL DEFAULT 1,
  `FarmTimes` int(11) NOT NULL DEFAULT 0,
  `FarmRem` int(11) NOT NULL DEFAULT 26,
  `PizzaSkill` int(2) NOT NULL DEFAULT 1,
  `PizzaRem` int(5) NOT NULL DEFAULT 26,
  `PizzaTimes` int(11) NOT NULL DEFAULT 0,
  `ArmsSkill` int(2) NOT NULL DEFAULT 1,
  `ArmsRem` int(5) NOT NULL DEFAULT 26,
  `ArmsTimes` int(11) NOT NULL DEFAULT 0,
  `BusSkill` int(2) NOT NULL DEFAULT 1,
  `BusRem` int(5) NOT NULL DEFAULT 26,
  `BusTimes` int(11) NOT NULL DEFAULT 0,
  `GarbageSkill` int(2) NOT NULL DEFAULT 1,
  `GarbageTimes` int(11) NOT NULL DEFAULT 0,
  `GarbageRem` int(5) NOT NULL DEFAULT 26,
  `Gifti` int(11) NOT NULL,
  `FactionTime` int(11) NOT NULL,
  `CreditsF` int(11) NOT NULL,
  `NMuted` int(11) NOT NULL DEFAULT 0,
  `HelpedPlayers` int(11) NOT NULL DEFAULT 0,
  `HiddenColor` int(11) NOT NULL DEFAULT 0,
  `GiftTime` int(11) NOT NULL DEFAULT 0,
  `Host` int(11) NOT NULL DEFAULT 0,
  `FightStyle` int(11) NOT NULL DEFAULT 0,
  `HUD1` int(11) NOT NULL DEFAULT 0,
  `HUD2` int(11) NOT NULL DEFAULT 0,
  `HUD3` int(11) NOT NULL DEFAULT 1,
  `Clan` int(4) NOT NULL DEFAULT 0,
  `CRank` int(2) NOT NULL DEFAULT 0,
  `ClanTag` int(2) NOT NULL DEFAULT 0,
  `ClanTime` int(11) NOT NULL DEFAULT 0,
  `ClanJoin` int(11) NOT NULL DEFAULT 0,
  `FactionJoin` int(11) NOT NULL DEFAULT 0,
  `ClanWarns` int(2) NOT NULL DEFAULT 0,
  `OnlineToday` int(2) NOT NULL DEFAULT 0,
  `OnlineThisWeek` int(2) NOT NULL DEFAULT 0,
  `OnlineLastWeek` int(2) NOT NULL DEFAULT 0,
  `LastIP` varchar(20) NOT NULL DEFAULT '0',
  `GasCan` int(2) NOT NULL DEFAULT 0,
  `ConnectedTimeMonth` int(11) NOT NULL,
  `Color` int(3) NOT NULL DEFAULT 0,
  `CarSlots` int(3) NOT NULL DEFAULT 2,
  `Car1` int(11) NOT NULL DEFAULT -1,
  `Car2` int(11) NOT NULL DEFAULT -1,
  `Car3` int(11) NOT NULL DEFAULT -1,
  `Car4` int(11) NOT NULL DEFAULT -1,
  `Car5` int(11) NOT NULL DEFAULT -1,
  `Car6` int(11) NOT NULL DEFAULT -1,
  `Car7` int(11) NOT NULL DEFAULT -1,
  `Car8` int(11) NOT NULL DEFAULT -1,
  `Car9` int(11) NOT NULL DEFAULT -1,
  `Car10` int(11) NOT NULL DEFAULT -1,
  `Raport1` int(11) NOT NULL DEFAULT 0,
  `Raport2` int(11) NOT NULL DEFAULT 0,
  `Raport3` int(11) NOT NULL DEFAULT 0,
  `Raport4` int(11) NOT NULL DEFAULT 0,
  `Raport5` int(11) NOT NULL DEFAULT 0,
  `Raport6` int(11) NOT NULL DEFAULT 0,
  `Raport7` int(11) NOT NULL DEFAULT 0,
  `Quest1` int(5) NOT NULL,
  `Quest2` int(5) NOT NULL,
  `QuestProgress1` int(5) NOT NULL,
  `QuestProgress2` int(5) NOT NULL,
  `QuestNeed1` int(5) NOT NULL,
  `QuestNeed2` int(5) NOT NULL,
  `QuestCar` int(5) NOT NULL DEFAULT 0,
  `Session` int(2) NOT NULL DEFAULT 0,
  `PaydayON` int(11) NOT NULL DEFAULT 0,
  `IPpanel` varchar(16) NOT NULL,
  `WTChannel` int(5) NOT NULL DEFAULT 0,
  `ReportMuted` int(5) NOT NULL DEFAULT 0,
  `gpci` varchar(128) NOT NULL,
  `adminfunction` varchar(128) NOT NULL DEFAULT '(null)',
  `OnlineTimeToday` int(11) NOT NULL DEFAULT 0,
  `WarnReason1` varchar(64) NOT NULL DEFAULT '(null)',
  `WarnReason2` varchar(64) NOT NULL DEFAULT '(null)',
  `TotalPP` int(11) NOT NULL DEFAULT 0,
  `AdminNote` varchar(64) NOT NULL,
  `Object1` int(2) NOT NULL DEFAULT 0,
  `Object2` int(2) NOT NULL DEFAULT 0,
  `Object3` int(2) NOT NULL DEFAULT 0,
  `Object4` int(2) NOT NULL DEFAULT 0,
  `Object5` int(2) NOT NULL DEFAULT 0,
  `Object6` int(2) NOT NULL DEFAULT 0,
  `Object7` int(2) NOT NULL DEFAULT 0,
  `Object8` int(2) NOT NULL DEFAULT 0,
  `Object9` int(2) NOT NULL DEFAULT 0,
  `Object10` int(2) NOT NULL DEFAULT 0,
  `Object11` int(2) NOT NULL DEFAULT 0,
  `Object12` int(2) NOT NULL DEFAULT 0,
  `Object13` int(2) NOT NULL DEFAULT 0,
  `Object14` int(2) NOT NULL DEFAULT 0,
  `Object15` int(2) NOT NULL DEFAULT 0,
  `Object16` int(2) NOT NULL DEFAULT 0,
  `Object17` int(2) NOT NULL DEFAULT 0,
  `Object18` int(2) NOT NULL DEFAULT 0,
  `Object19` int(2) NOT NULL DEFAULT 0,
  `Object20` int(2) NOT NULL DEFAULT 0,
  `Object21` int(2) NOT NULL DEFAULT 0,
  `Object22` int(2) NOT NULL DEFAULT 0,
  `Object23` int(2) NOT NULL DEFAULT 0,
  `Object24` int(2) NOT NULL DEFAULT 0,
  `Object25` int(2) NOT NULL DEFAULT 0,
  `Object26` int(2) NOT NULL DEFAULT 0,
  `Object27` int(2) NOT NULL DEFAULT 0,
  `Object28` int(2) NOT NULL DEFAULT 0,
  `Object29` int(2) NOT NULL DEFAULT 0,
  `Object30` int(2) NOT NULL DEFAULT 0,
  `Object31` int(2) NOT NULL DEFAULT 0,
  `Object32` int(2) NOT NULL DEFAULT 0,
  `Object33` int(2) NOT NULL DEFAULT 0,
  `Object34` int(2) NOT NULL DEFAULT 0,
  `Object35` int(2) NOT NULL DEFAULT 0,
  `Object36` int(2) NOT NULL DEFAULT 0,
  `Object37` int(2) NOT NULL DEFAULT 0,
  `Object38` int(2) NOT NULL DEFAULT 0,
  `Object39` int(2) NOT NULL DEFAULT 0,
  `Object40` int(2) NOT NULL DEFAULT 0,
  `Object41` int(2) NOT NULL DEFAULT 0,
  `Object42` int(2) NOT NULL DEFAULT 0,
  `Object43` int(2) NOT NULL DEFAULT 0,
  `Object44` int(2) NOT NULL DEFAULT 0,
  `Object45` int(2) NOT NULL DEFAULT 0,
  `Object46` int(2) NOT NULL DEFAULT 0,
  `Object47` int(2) NOT NULL DEFAULT 0,
  `Object48` int(2) NOT NULL DEFAULT 0,
  `Object49` int(2) NOT NULL DEFAULT 0,
  `Object50` int(2) NOT NULL DEFAULT 0,
  `aplicatie` int(2) NOT NULL DEFAULT 0,
  `YouTuber` int(11) NOT NULL,
  `YouTubeLink` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `vehicles`
--

CREATE TABLE `vehicles` (
  `ID` int(11) NOT NULL,
  `Model` int(5) NOT NULL,
  `Color1` int(5) NOT NULL DEFAULT -1,
  `Color2` int(5) NOT NULL DEFAULT -1,
  `Group` int(3) NOT NULL DEFAULT 0,
  `Rank` int(2) NOT NULL DEFAULT 0,
  `Job` int(3) NOT NULL DEFAULT 0,
  `Rotation` float NOT NULL,
  `PosX` float NOT NULL,
  `PosY` float NOT NULL,
  `PosZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Eliminarea datelor din tabel `vehicles`
--

INSERT INTO `vehicles` (`ID`, `Model`, `Color1`, `Color2`, `Group`, `Rank`, `Job`, `Rotation`, `PosX`, `PosY`, `PosZ`) VALUES
(1, 509, 3, 3, 0, 0, 0, 359.812, 1783.29, -1865.96, 13.0817),
(2, 509, 3, 3, 0, 0, 0, 1.7586, 1784.9, -1865.8, 13.0765),
(3, 510, 3, 3, 0, 0, 0, 1.8864, 1780.13, -1865.95, 13.1799),
(4, 510, 3, 3, 0, 0, 0, 3.2173, 1781.52, -1865.89, 13.1744),
(5, 509, 3, 3, 0, 0, 0, 1.5418, 1743.75, -1862.53, 13.0886),
(6, 509, 3, 3, 0, 0, 0, 0.2961, 1745.3, -1862.51, 13.0868),
(7, 510, 3, 3, 0, 0, 0, 1.3846, 1741.05, -1862.58, 13.1841),
(8, 510, 3, 3, 0, 0, 0, 3.4108, 1742.38, -1862.52, 13.1723),
(9, 509, -1, -1, 0, 0, 0, 89.6512, 1844.37, -1860.65, 12.8948),
(10, 462, -1, -1, 0, 0, 0, 181.473, 1836.54, -1853.26, 12.9819),
(11, 462, -1, -1, 0, 0, 0, 181.873, 1839.79, -1853.23, 12.9849),
(12, 462, -1, -1, 0, 0, 0, 358.95, 1834.82, -1870.72, 12.987),
(13, 462, -1, -1, 0, 0, 0, 1.0992, 1837.86, -1870.91, 12.9858),
(14, 462, -1, -1, 0, 0, 0, 359.423, 1844.58, -1871.39, 12.9879),
(15, 543, -1, -1, 0, 0, 0, 359.541, 1841.29, -1871.08, 13.2091),
(16, 462, -1, -1, 0, 0, 0, 90.6615, 1865.92, -1865.75, 13.1635),
(17, 462, -1, -1, 0, 0, 0, 88.536, 1865.98, -1863.92, 13.172),
(18, 462, -1, -1, 0, 0, 0, 92.4187, 1865.88, -1867.24, 13.1513),
(19, 462, -1, -1, 0, 0, 0, 91.9116, 1865.88, -1868.83, 13.1392),
(20, 462, -1, -1, 0, 0, 0, 96.1952, 1865.93, -1870.21, 13.1271),
(21, 462, -1, -1, 0, 0, 0, 91.7427, 1865.95, -1871.8, 13.1156),
(22, 554, -1, -1, 0, 0, 0, 337.07, 2239.49, -1630.69, 15.7426),
(23, 401, -1, -1, 0, 0, 0, 271.936, 2353.85, -1753.9, 13.3007),
(24, 468, -1, -1, 0, 0, 0, 352.549, 2450.43, -1795.95, 14.0615),
(25, 462, -1, -1, 0, 0, 0, 270.611, 2468.81, -1755.47, 13.1419),
(26, 418, -1, -1, 0, 0, 0, 0.2794, 2493.87, -1755.01, 13.6076),
(27, 565, -1, -1, 0, 0, 0, 207.252, 2659.72, -1841.23, 10.5634),
(28, 481, -1, -1, 0, 0, 0, 178.68, 2759.8, -1875.57, 9.1931),
(29, 500, -1, -1, 0, 0, 0, 2.9916, 2767.94, -1875.55, 9.8829),
(30, 489, -1, -1, 0, 0, 0, 79.3965, 2822.94, -1723.45, 10.0821),
(31, 581, -1, -1, 0, 0, 0, 266.993, 2795.45, -1549.54, 10.5166),
(32, 542, -1, -1, 0, 0, 0, 185.792, 2814.61, -1458.01, 20.0059),
(33, 468, -1, -1, 0, 0, 0, 266.716, 2492.8, -1298.08, 32.3194),
(34, 509, -1, -1, 0, 0, 0, 358.45, 2460.62, -1277.18, 23.464),
(35, 474, 3, 3, 0, 0, 0, 177.41, 2429.8, -1223.06, 24.9496),
(36, 566, -1, -1, 0, 0, 0, 179.787, 2340.31, -1316.75, 23.7525),
(37, 542, -1, -1, 0, 0, 0, 92.5309, 2358.14, -1360.42, 23.6566),
(38, 510, -1, -1, 0, 0, 0, 92.4031, 2325.38, -1508.66, 25.2981),
(39, 510, -1, -1, 0, 0, 0, 182.39, 2304.53, -1521.74, 25.4735),
(40, 510, -1, -1, 0, 0, 0, 239.406, 2308.25, -1545.9, 25.009),
(41, 521, -1, -1, 0, 0, 0, 1.1783, 2405.42, -1535.64, 23.5651),
(42, 602, -1, -1, 0, 0, 0, 89.9498, 2159.13, -1805.21, 13.2685),
(43, 509, -1, -1, 0, 0, 0, 246.856, 2113.02, -1728.28, 13.0466),
(44, 478, -1, -1, 0, 0, 0, 359.671, 2052.5, -1904.23, 13.4583),
(45, 475, -1, -1, 0, 0, 0, 1.256, 1912.93, -1873.73, 13.3916),
(46, 481, -1, -1, 0, 0, 0, 4.8674, 1938.43, -1985.75, 13.0371),
(47, 491, -1, -1, 0, 0, 0, 1.0062, 1980.68, -1995.68, 13.2307),
(48, 555, -1, -1, 0, 0, 0, 87.1935, 1947.74, -2114.02, 13.2772),
(49, 558, -1, -1, 0, 0, 0, 88.5185, 1947.53, -2123.65, 13.1192),
(50, 534, -1, -1, 0, 0, 0, 180.321, 1793.33, -2149.02, 13.2714),
(51, 535, -1, -1, 0, 0, 0, 179.287, 1744.6, -2136.27, 13.3383),
(52, 482, -1, -1, 0, 0, 0, 178.141, 1705.02, -2129.69, 13.557),
(53, 536, -1, -1, 0, 0, 0, 358.963, 1698.99, -2093.84, 13.1678),
(54, 567, -1, -1, 0, 0, 0, 88.6971, 1667.98, -2113.28, 13.3059),
(55, 578, -1, -1, 0, 0, 0, 87.0461, 1669.26, -2165.02, 14.1183),
(56, 404, -1, -1, 0, 0, 0, 179.428, 1518.71, -2211.89, 13.6059),
(57, 571, -1, -1, 0, 0, 0, 226.251, 2285.42, -2354.35, 12.783),
(58, 571, -1, -1, 0, 0, 0, 222.187, 2289.1, -2342.82, 12.8355),
(59, 571, -1, -1, 0, 0, 0, 225.47, 2292.53, -2346.66, 12.8357),
(60, 482, -1, -1, 0, 0, 0, 267.461, 2528.2, -2010.36, 13.5607),
(61, 485, -1, -1, 0, 0, 0, 89.0116, 1953.8, -2193.55, 13.1821),
(62, 485, -1, -1, 0, 0, 0, 182.276, 1940.81, -2235.07, 13.1838),
(63, 577, -1, -1, 0, 0, 0, 175.859, 1932.81, -2377.85, 13.4522),
(64, 608, -1, -1, 0, 0, 0, 81.9305, 1936.42, -2397.05, 14.0552),
(65, 487, -1, -1, 0, 0, 0, 352.317, 1973.07, -2647.95, 13.7008),
(66, 487, -1, -1, 0, 0, 0, 1.5214, 1955.41, -2646.5, 13.6973),
(67, 485, -1, -1, 0, 0, 0, 88.4399, 1963.75, -2610.6, 13.1874),
(68, 519, -1, -1, 0, 0, 0, 358.421, 1890.38, -2627.77, 14.4122),
(69, 513, -1, -1, 0, 0, 0, 351.281, 1822.24, -2632.95, 14.0722),
(70, 511, -1, -1, 0, 0, 0, 360, 1684.14, -2628.02, 14.8523),
(71, 593, -1, -1, 0, 0, 0, 357.985, 1615.94, -2629.73, 13.943),
(72, 485, -1, -1, 0, 0, 0, 88.2834, 1652.38, -2547.68, 13.1878),
(73, 485, -1, -1, 0, 0, 0, 88.036, 1655.06, -2538.22, 13.1842),
(74, 445, -1, -1, 0, 0, 0, 146.913, 1837.15, -1572.09, 13.3503),
(75, 440, 1, 1, 0, 0, 0, 271.59, 1362.03, -1658.92, 13.471),
(76, 405, -1, -1, 0, 0, 0, 356.672, 1339.41, -1764.74, 13.4371),
(77, 585, -1, -1, 0, 0, 0, 178.987, 1281.37, -1666.89, 13.1509),
(78, 533, -1, -1, 0, 0, 0, 359.509, 1226.4, -1865.39, 13.1604),
(79, 510, -1, -1, 0, 0, 0, 276.326, 1863.76, -1393.26, 13.0425),
(80, 510, -1, -1, 0, 0, 0, 273.049, 1863.71, -1395.01, 13.056),
(81, 510, -1, -1, 0, 0, 0, 269.017, 1869.07, -1362.89, 18.7195),
(82, 510, -1, -1, 0, 0, 0, 175.758, 1943.62, -1367.78, 18.1189),
(83, 510, -1, -1, 0, 0, 0, 92.1796, 1909.69, -1418.11, 15.9386),
(84, 434, -1, -1, 0, 0, 0, 249.872, 1785.68, -1180.65, 23.7673),
(85, 401, -1, -1, 0, 0, 0, 343.546, 1555.7, -1027.57, 23.7466),
(86, 436, -1, -1, 0, 0, 0, 101.226, 1331.13, -1080.35, 24.9877),
(87, 605, -1, -1, 0, 0, 0, 274.176, 1278.49, -939.959, 41.895),
(88, 405, -1, -1, 0, 0, 0, 184.105, 980.198, -914.909, 41.5209),
(89, 400, -1, -1, 0, 0, 0, 102.739, 589.479, -1353.7, 14.4028),
(90, 404, -1, -1, 0, 0, 0, 91.5149, 686.679, -1413.12, 13.2275),
(91, 437, -1, -1, 0, 0, 0, 89.2659, 599.195, -1509.48, 15.327),
(92, 496, -1, -1, 0, 0, 0, 177.181, 847.09, -1503.08, 12.7671),
(93, 496, -1, -1, 0, 0, 0, 91.0754, 720.94, -1581.56, 14.0567),
(94, 561, -1, -1, 0, 0, 0, 180.694, 852.312, -1363.93, 13.3108),
(95, 404, -1, -1, 0, 0, 0, 273.682, 1015.57, -1358.84, 13.0208),
(96, 509, -1, -1, 0, 0, 0, 182.109, 766.036, -1747.09, 12.066),
(97, 426, -1, -1, 0, 0, 0, 348.584, 641.869, -1704.49, 14.3627),
(98, 509, -1, -1, 0, 0, 0, 90.7645, 539.307, -1688.67, 18.3465),
(99, 586, -1, -1, 0, 0, 0, 131.253, 327.035, -1473.33, 33.868),
(100, 509, -1, -1, 0, 0, 0, 36.7312, 247.484, -1469.65, 23.2363),
(101, 471, -1, -1, 0, 0, 0, 357.595, 458.159, -1779.61, 4.9527),
(102, 457, -1, -1, 0, 0, 0, 1.55, 478.624, -1825.27, 5.0417),
(103, 539, -1, -1, 0, 0, 0, 272.281, 666.504, -1879.77, 4.82),
(104, 566, -1, -1, 0, 0, 0, 118.958, 334.076, -1342.64, 14.1753),
(105, 400, -1, -1, 0, 0, 0, 277.788, 1185.17, -925.163, 43.2723),
(106, 568, -1, -1, 0, 0, 0, 115.534, 1773.54, -790.196, 62.9578),
(107, 473, -1, -1, 0, 0, 0, 180.097, 719.003, -1636.46, -0.1546),
(108, 473, -1, -1, 0, 0, 0, 178.529, 718.966, -1627.71, -0.1771),
(109, 412, 3, 1, 0, 0, 0, 181.639, 2294.53, 607.263, 10.5616),
(110, 516, -1, -1, 0, 0, 0, 89.8527, 2542.7, 1105.28, 10.6882),
(111, 600, 1, 2, 0, 0, 0, 270.016, 2441.96, 1355.32, 10.4492),
(112, 474, -1, -1, 0, 0, 0, 269.8, 2442.04, 1351.81, 10.6753),
(113, 479, -1, -1, 0, 0, 0, 269.08, 2002.33, 1265.92, 10.6411),
(114, 475, -1, -1, 0, 0, 0, 268.849, 2023.67, 1334.69, 10.2891),
(115, 576, -1, -1, 0, 0, 0, 182.896, 2034.85, 1496.47, 10.3284),
(116, 419, -1, -1, 0, 0, 0, 359.076, 2207.88, 1787.92, 10.5245),
(117, 475, -1, -1, 0, 0, 0, 178.277, 2199.82, 1821.75, 10.5407),
(118, 518, -1, -1, 0, 0, 0, 88.5952, 2325.45, 1785.27, 10.5292),
(119, 505, -1, -1, 0, 0, 0, 90.6484, 2531.57, 1836.14, 10.9196),
(120, 422, -1, -1, 0, 0, 0, 359.911, 2523.19, 2006.93, 10.8256),
(121, 504, -1, -1, 0, 0, 0, 178.462, 2547.55, 2196.41, 10.5338),
(122, 500, -1, -1, 0, 0, 0, 268.233, 1908.39, 2390.38, 10.9523),
(123, 508, -1, -1, 0, 0, 0, 90.879, 1908.73, 2280.33, 11.2364),
(124, 414, -1, -1, 0, 0, 0, 92.9936, 1451.62, 1880.06, 10.9389),
(125, 487, -1, -1, 0, 0, 0, 91.178, 1544, 1667.16, 10.9712),
(126, 592, -1, -1, 0, 0, 0, 180.374, 1479.31, 1798.81, 12.0048),
(127, 512, -1, -1, 0, 0, 0, 276.212, 1328.29, 1782.64, 11.055),
(128, 487, -1, -1, 0, 0, 0, 272.475, 1337.02, 1614.14, 10.9634),
(129, 487, -1, -1, 0, 0, 0, 264.882, 1337.88, 1627.57, 10.9531),
(130, 519, -1, -1, 0, 0, 0, 268.523, 1288.88, 1362.19, 11.7454),
(131, 512, -1, -1, 0, 0, 0, 264.82, 1280.07, 1330.02, 11.0504),
(132, 513, -1, -1, 0, 0, 0, 7.4674, 1403.36, 1218.74, 11.3572),
(133, 593, -1, -1, 0, 0, 0, 5.0484, 1413.99, 1217.72, 11.2396),
(134, 511, -1, -1, 0, 0, 0, 3.2613, 1594.35, 1240.28, 12.1148),
(135, 511, -1, -1, 0, 0, 0, 91.3682, 1623.33, 1337.53, 12.1246),
(136, 540, -1, -1, 0, 0, 0, 179.75, 1666.48, 1297, 10.7416),
(137, 479, -1, -1, 0, 0, 0, 90.3137, 1551.01, 1024.93, 10.5311),
(138, 412, -1, -1, 0, 0, 0, 270.45, 1380.94, 1058.3, 10.7115),
(139, 467, -1, -1, 0, 0, 0, 358.527, 1036.26, 1398.34, 5.4636),
(140, 473, -1, -1, 0, 0, 0, 179.877, 1619.53, 593.07, -0.358),
(141, 473, -1, -1, 0, 0, 0, 87.3583, 1631.29, 573.007, -0.3858),
(142, 473, -1, -1, 0, 0, 0, 90.8698, 1624.85, 573.023, -0.2494),
(143, 473, -1, -1, 0, 0, 0, 181, 1636.89, 594.021, -0.2125),
(144, 473, -1, -1, 0, 0, 0, 89.7492, 2368.04, 519.765, -0.3253),
(145, 452, -1, -1, 0, 0, 0, 92.3875, 2356.07, 519.551, -0.3697),
(146, 452, -1, -1, 0, 0, 0, 183.659, 2374.28, 539.155, -0.4487),
(147, 473, -1, -1, 0, 0, 0, 179.509, 2345.99, 540.773, -0.1944),
(148, 525, -1, -1, 0, 0, 8, 179.778, 1626.62, 2197.16, 10.698),
(149, 525, -1, -1, 0, 0, 8, 180.689, 1632.54, 2197.11, 10.7007),
(150, 525, -1, -1, 0, 0, 8, 180.33, 1638.16, 2197.16, 10.6974),
(151, 525, -1, -1, 0, 0, 8, 180.279, 1643.76, 2197.29, 10.6996),
(152, 525, -1, -1, 0, 0, 8, 183.048, 1649.35, 2197.33, 10.7058),
(153, 525, -1, -1, 0, 0, 8, 180.127, 1666.65, 2204.12, 10.6885),
(154, 525, -1, -1, 0, 0, 8, 179.419, 1671.58, 2204.09, 10.6996),
(155, 407, 3, 0, 14, 4, 0, 359.823, 1592.89, 1818.56, 11.057),
(156, 407, 3, 0, 14, 4, 0, 3.76023, 1626.59, 1819.03, 10.9827),
(157, 599, 3, 1, 14, 2, 0, 180.522, 1616.7, 1832.23, 10.9221),
(158, 416, 3, 1, 14, 1, 0, 181.747, 1613.68, 1849.16, 10.8623),
(159, 416, 3, 1, 14, 1, 0, 181.776, 1609.52, 1849.32, 10.8625),
(160, 416, 3, 1, 14, 1, 0, 181.74, 1605.4, 1849.58, 11.0117),
(161, 416, 3, 1, 14, 1, 0, 181.74, 1601.17, 1849.67, 10.8623),
(162, 416, 3, 1, 14, 1, 0, 181.74, 1596.8, 1849.45, 10.8623),
(163, 416, 3, 1, 14, 2, 0, 181.741, 1592.61, 1849.54, 10.8623),
(164, 416, 3, 1, 14, 2, 0, 181.662, 1642.11, 1852.67, 10.9168),
(165, 582, 1, 5, 9, 1, 0, 0.357767, -345.879, 1515.57, 75.2991),
(166, 582, 1, 5, 9, 1, 0, 0.702557, -339.813, 1515.61, 75.3086),
(167, 582, 1, 5, 9, 1, 0, 0.703677, -333.397, 1515.62, 75.2994),
(168, 582, 1, 5, 9, 1, 0, 0.436263, -327.011, 1515.65, 75.3016),
(169, 582, 1, 5, 9, 1, 0, 0.912236, -320.86, 1515.68, 75.2983),
(170, 582, 1, 5, 9, 1, 0, 359.818, -314.685, 1515.73, 75.2991),
(171, 488, 1, 5, 9, 3, 0, 264.666, -355.029, 1523.3, 75.7693),
(172, 488, 1, 5, 9, 3, 0, 139.053, -295.245, 1538.23, 75.6459),
(173, 582, 1, 5, 9, 1, 0, 134.037, -265.403, 1542.87, 75.4744),
(174, 582, 1, 5, 9, 1, 0, 134.854, -270.194, 1547.8, 75.4701),
(175, 582, 1, 5, 9, 1, 0, 133.779, -275.245, 1552.77, 75.4684),
(176, 582, 1, 5, 9, 1, 0, 134.914, -280.241, 1557.82, 75.3016),
(177, 582, 1, 5, 9, 1, 0, 134.6, -285.265, 1562.82, 75.2995),
(178, 582, 1, 5, 9, 1, 0, 134.554, -290.199, 1567.66, 75.2995),
(179, 582, 1, 5, 9, 1, 0, 134.46, -295.053, 1572.6, 75.2995),
(180, 582, 1, 5, 9, 1, 0, 135.176, -299.849, 1577.5, 75.3016),
(181, 582, 1, 5, 9, 1, 0, 134.759, -304.8, 1582.51, 75.3016),
(182, 563, 3, 1, 14, 3, 0, 266.62, 1607.85, 1805.22, 31.1742),
(183, 599, 3, 1, 14, 3, 0, 179.146, 1592.88, 1832.18, 11.0084),
(184, 438, 6, 6, 13, 1, 0, 270.773, 1777.9, -1928.78, 13.5037),
(185, 438, 6, 6, 13, 1, 0, 270.78, 1777.98, -1924.8, 13.504),
(186, 438, 6, 6, 13, 1, 0, 270.78, 1777.9, -1921, 13.504),
(187, 438, 6, 6, 13, 1, 0, 270.78, 1778, -1917.23, 13.504),
(188, 438, 6, 6, 13, 1, 0, 270.78, 1777.97, -1913.46, 13.504),
(189, 426, 6, 6, 13, 2, 0, 358.74, 1788.09, -1932.53, 13.0717),
(190, 426, 6, 6, 13, 2, 0, 358.74, 1792, -1932.6, 13.0717),
(191, 426, 6, 6, 13, 1, 0, 358.74, 1795.75, -1932.53, 13.0717),
(192, 560, 6, 6, 13, 3, 0, 358.739, 1799.45, -1932.51, 13.0471),
(193, 560, 6, 6, 13, 3, 0, 358.441, 1803.18, -1932.43, 13.0454),
(194, 431, -1, -1, 0, 0, 7, 90.8417, 1650.12, -2259.14, 13.5827),
(195, 431, -1, -1, 0, 0, 7, 89.0003, 1635.99, -2259.2, 13.5699),
(196, 431, -1, -1, 0, 0, 7, 89.0491, 1622.2, -2258.97, 13.5796),
(197, 431, -1, -1, 0, 0, 7, 89.3305, 1607.09, -2258.84, 13.5999),
(198, 431, -1, -1, 0, 0, 7, 89.1765, 1593.37, -2258.76, 13.6205),
(199, 431, -1, -1, 0, 0, 7, 269.762, 1593.88, -2248.27, 13.6171),
(200, 431, -1, -1, 0, 0, 7, 268.301, 1633.58, -2248.35, 13.5744),
(201, 431, -1, -1, 0, 0, 7, 358.666, 1577.41, -2215.01, 13.7255),
(202, 431, -1, -1, 0, 0, 7, 357.92, 1584.66, -2215.52, 13.7368),
(203, 431, -1, -1, 0, 0, 7, 179.428, 1590.82, -2157.88, 13.7303),
(204, 431, -1, -1, 0, 0, 7, 179.302, 1596.57, -2158.04, 13.7311),
(205, 431, -1, -1, 0, 0, 7, 180, 1602.01, -2158.18, 13.5099),
(206, 431, -1, -1, 0, 0, 7, 178.707, 1607.79, -2158.32, 13.5099),
(207, 431, -1, -1, 0, 0, 7, 178.586, 1613.44, -2158.46, 13.7303),
(208, 431, -1, -1, 0, 0, 7, 177.477, 1618.97, -2158.66, 13.507),
(209, 431, -1, -1, 0, 0, 7, 177.536, 1624.05, -2158.96, 13.7325),
(210, 448, 182, 182, 0, 0, 5, 90.2997, 2122.39, -1780.53, 13.0004),
(211, 448, 128, 128, 0, 0, 5, 0, 2121.6, -1785.01, 12.9978),
(212, 448, 145, 145, 0, 0, 5, 0, 2118.78, -1785.04, 12.8723),
(213, 448, 162, 162, 0, 0, 5, 0, 2115.91, -1785, 13.001),
(214, 448, 241, 241, 0, 0, 5, 0, 2112.56, -1784.94, 12.9755),
(215, 448, 134, 134, 0, 0, 5, 0, 2109.47, -1784.84, 12.9756),
(216, 448, 240, 240, 0, 0, 5, 0, 2106.04, -1784.93, 12.9755),
(217, 448, 243, 243, 0, 0, 5, 0.003015, 2102.2, -1784.86, 12.8724),
(218, 448, 175, 175, 0, 0, 5, 90.3, 2092.41, -1812.45, 12.8722),
(219, 448, 194, 194, 0, 0, 5, 90.3002, 2092.43, -1814.18, 12.8722),
(220, 448, 137, 137, 0, 0, 5, 90.3001, 2092.39, -1815.81, 12.8722),
(221, 448, 228, 228, 0, 0, 5, 90.5719, 2092.42, -1817.31, 13.0078),
(222, 448, 139, 139, 0, 0, 5, 90.3, 2092.41, -1819.15, 12.8722),
(223, 448, 222, 222, 0, 0, 5, 90.3005, 2092.47, -1820.75, 13.0022),
(224, 531, -1, -1, 0, 0, 6, 182.321, -387.195, -1453.11, 25.7079),
(225, 531, -1, -1, 0, 0, 6, 179.333, -390.848, -1453.11, 25.7168),
(226, 531, -1, -1, 0, 0, 6, 173.955, -363.621, -1437.97, 25.6074),
(227, 531, -1, -1, 0, 0, 6, 176.927, -366.201, -1437.91, 25.5936),
(228, 531, -1, -1, 0, 0, 6, 180.209, -369.075, -1437.78, 25.6122),
(229, 531, -1, -1, 0, 0, 6, 179.541, -372.153, -1437.86, 25.6123),
(230, 531, -1, -1, 0, 0, 6, 91.835, -374.065, -1425.52, 25.5987),
(231, 531, -1, -1, 0, 0, 6, 89.9735, -373.994, -1422.27, 25.599),
(232, 531, -1, -1, 0, 0, 6, 92.3336, -374.052, -1419.32, 25.6023),
(233, 531, -1, -1, 0, 0, 6, 92.3748, -374.155, -1417.13, 25.6035),
(234, 531, -1, -1, 0, 0, 6, 269.223, -382.394, -1413.88, 25.7195),
(235, 531, -1, -1, 0, 0, 6, 267.417, -382.202, -1417.57, 25.606),
(236, 515, 139, 139, 0, 0, 14, 162.201, -77.674, -1107.72, 2.09888),
(237, 515, 137, 137, 0, 0, 14, 161.602, -70.8716, -1110.39, 2.10064),
(238, 515, 155, 155, 0, 0, 14, 161.087, -38.1724, -1121.23, 2.09856),
(239, 515, 3, 3, 0, 0, 14, 161.507, -64.2626, -1112.34, 2.12544),
(240, 515, 228, 228, 0, 0, 14, 160.328, -45.1084, -1118.78, 2.09341),
(241, 515, 6, 6, 0, 0, 14, 160.57, -58.217, -1114.34, 2.09355),
(242, 515, 222, 222, 0, 0, 14, 161.166, -51.7079, -1116.58, 2.09464),
(243, 515, 175, 175, 0, 0, 14, 334.519, -42.36, -1152.49, 2.09908),
(244, 515, 154, 154, 0, 0, 14, 334.753, -50.1163, -1149.17, 2.09608),
(245, 515, 214, 214, 0, 0, 14, 337.575, -56.7344, -1146.31, 2.10141),
(246, 515, 132, 132, 0, 0, 14, 159.822, -30.2103, -1123.95, 2.09828),
(247, 522, -1, -1, 0, 0, 0, 324.408, -2249.03, -1703.72, 480.091),
(248, 522, -1, -1, 0, 0, 0, 311.237, -2247.22, -1705.35, 480.064),
(249, 522, -1, -1, 0, 0, 0, 318.571, -2245.67, -1706.7, 480.045),
(250, 568, -1, -1, 0, 0, 0, 256.832, -2355.1, -1631.33, 483.554),
(251, 568, -1, -1, 0, 0, 0, 254.718, -2356.17, -1635.63, 483.568),
(252, 444, -1, -1, 0, 0, 0, 256.242, -2348.16, -1613.88, 484.016),
(253, 444, -1, -1, 0, 0, 0, 258.657, -2346.88, -1608.94, 484.68),
(254, 480, -1, -1, 30, 1, 0, 2.2859, 527.331, -1290.67, 16.9406),
(255, 589, 243, 243, 30, 1, 0, 359.486, 531.859, -1290.7, 16.8192),
(256, 603, 3, 6, 30, 1, 0, 358.43, 536.91, -1291.4, 16.9963),
(257, 579, 139, 139, 30, 1, 0, 359.163, 543.027, -1290.27, 17.064),
(258, 507, 135, 135, 30, 1, 0, 0.730357, 550.81, -1290.65, 17.0005),
(259, 565, 226, 226, 30, 1, 0, 356.145, 557.697, -1291.6, 16.8268),
(260, 426, 222, 222, 30, 1, 0, 307.718, 530.009, -1278.46, 16.9255),
(261, 565, 154, 154, 30, 1, 0, 301.518, 537.425, -1272.81, 16.8246),
(262, 462, -1, -1, 30, 1, 0, 185.932, 541.583, -1268.12, 16.8334),
(263, 568, -1, -1, 30, 1, 0, 180.338, 2103.98, 1398.74, 10.6353),
(264, 555, -1, -1, 30, 1, 0, 174.947, 2123.43, 1397.81, 10.5583),
(265, 526, 222, 222, 30, 1, 0, 180.974, 2129.5, 1398.42, 10.5288),
(266, 504, 128, 128, 30, 1, 0, 182.631, 2135.85, 1397.9, 10.4523),
(267, 496, -1, -1, 30, 1, 0, 180.532, 2142.37, 1398.47, 10.4187),
(268, 602, -1, -1, 30, 1, 0, 180.585, 2148.74, 1397.68, 10.5656),
(269, 469, -1, -1, 30, 1, 0, 2.58286, 2168.87, 1411.42, 10.7364),
(270, 603, 135, 1, 30, 1, 0, 1.05295, 2148.79, 1408.7, 10.8199),
(271, 500, -1, -1, 30, 1, 0, 0.536014, 2142.3, 1409.02, 10.964),
(272, 506, 139, 139, 30, 1, 0, 0, 2135.85, 1408.38, 10.4873),
(273, 533, -1, -1, 30, 1, 0, 0, 2129.49, 1409.06, 10.4239),
(274, 558, -1, -1, 30, 1, 0, 0.978661, 2123.16, 1409.43, 10.3941),
(275, 568, -1, -1, 30, 1, 0, 359.051, 2103.92, 1408.52, 10.6097),
(276, 522, -1, -1, 30, 1, 0, 271.971, 2229.69, 1416.45, 10.6204),
(277, 522, -1, -1, 30, 1, 0, 274.818, 2229.56, 1414.47, 10.6219),
(278, 522, -1, -1, 30, 1, 0, 270.064, 2229.62, 1410.07, 10.6162),
(279, 522, -1, -1, 30, 1, 0, 272.84, 2229.78, 1408.13, 10.6353),
(280, 471, -1, -1, 30, 1, 0, 272.531, 2229.2, 1399.95, 10.4862),
(281, 471, -1, -1, 30, 1, 0, 269.229, 2229.3, 1396.64, 10.4801),
(285, 469, 1, 1, 11, 1, 0, 266.134, 1015.23, -346.209, 74.0738),
(286, 469, 1, 1, 11, 1, 0, 268.634, 1015.39, -339.538, 74.0722),
(287, 469, 1, 1, 11, 1, 0, 267.268, 1015.69, -331.563, 74.0738),
(288, 469, 1, 1, 11, 1, 0, 269.733, 1015.92, -323.932, 74.0738),
(289, 461, 175, 175, 11, 3, 0, 199.788, 1059.65, -294.88, 73.5652),
(290, 402, 175, 175, 11, 1, 0, 179.213, 1063.9, -295.136, 73.7458),
(291, 402, 175, 175, 11, 1, 0, 179.849, 1069.24, -295.238, 73.7458),
(292, 402, 175, 175, 11, 1, 0, 180.868, 1075.82, -295.121, 73.7439),
(293, 402, 175, 175, 11, 2, 0, 179.721, 1082.15, -295.098, 73.7511),
(294, 461, 175, 175, 11, 1, 0, 152.332, 1085.98, -294.8, 73.5776),
(295, 415, 175, 175, 11, 4, 0, 89.3157, 1096.71, -304.399, 73.7153),
(296, 560, 175, 175, 11, 3, 0, 88.1373, 1096.29, -308.672, 73.6362),
(297, 487, 175, 175, 11, 3, 0, 2.35617, 1099.09, -349.003, 74.0703),
(298, 462, 137, 137, 12, 1, 0, 90.2957, 2409.05, 1681.76, 10.6131),
(299, 462, 137, 137, 12, 1, 0, 89.9849, 2409.08, 1680.2, 10.5966),
(300, 462, 137, 137, 12, 1, 0, 90.3704, 2409.04, 1678.64, 10.6143),
(301, 462, 137, 137, 12, 1, 0, 98.4236, 2409.13, 1677.19, 10.6152),
(302, 547, 137, 137, 12, 1, 0, 359.232, 2408.5, 1667.69, 10.4665),
(303, 547, 137, 137, 12, 1, 0, 359.657, 2402.04, 1667.63, 10.4659),
(304, 445, 137, 137, 12, 1, 0, 359.521, 2395.55, 1667.79, 10.6298),
(305, 405, 137, 137, 12, 1, 0, 358.187, 2389.25, 1667.71, 10.5939),
(306, 405, 137, 137, 12, 1, 0, 179.392, 2386.23, 1658.59, 10.5939),
(307, 547, 137, 137, 12, 1, 0, 181.043, 2392.62, 1658.93, 10.4917),
(308, 547, 137, 137, 12, 1, 0, 181.059, 2398.97, 1658.94, 10.4916),
(309, 487, 137, 137, 12, 1, 0, 176.913, 2401.03, 1647.56, 10.9665),
(310, 487, 154, 154, 12, 1, 0, 175.562, 2407.92, 1647.14, 10.997),
(311, 408, 1, 1, 0, 0, 10, 181.14, 2540.96, 2791.33, 11.2968),
(312, 408, 1, 1, 0, 0, 10, 179.82, 2549.47, 2791.32, 11.5698),
(313, 408, 1, 1, 0, 0, 10, 181.08, 2557.74, 2791.14, 11.2519),
(314, 408, 1, 1, 0, 0, 10, 179.641, 2565.92, 2791.29, 11.5619),
(315, 408, 1, 1, 0, 0, 10, 180.96, 2574.22, 2790.96, 11.2501),
(316, 408, 1, 1, 0, 0, 10, 91.6794, 2585.72, 2780.19, 11.2913),
(317, 408, 1, 1, 0, 0, 10, 90.5999, 2586.12, 2768.41, 11.2913),
(318, 408, 1, 1, 0, 0, 10, 90.2349, 2586.68, 2752.17, 11.4883),
(319, 408, 1, 1, 0, 0, 10, 89.101, 2586.65, 2743.89, 11.5567),
(320, 408, 1, 1, 0, 0, 10, 89.1006, 2586.39, 2731.54, 11.5521),
(321, 497, 0, 1, 8, 3, 0, 176.024, 2319.43, 2465.99, 38.86),
(322, 563, 0, 1, 8, 1, 0, 175.48, 2307.25, 2466.95, 39.39),
(323, 411, 1, 1, 8, 1, 0, 177.4, 2308.78, 2453.89, 10.547),
(324, 427, 0, 1, 8, 3, 0, 180.324, 2304.09, 2453.11, 10.952),
(325, 598, 0, 1, 8, 1, 0, 270.736, 2274.32, 2418.64, 10.49),
(326, 598, 0, 1, 8, 1, 0, 88.427, 2301.43, 2418.49, 10.489),
(327, 523, 1, 1, 8, 1, 0, 181.153, 2311.24, 2420.82, 10.389),
(328, 523, 1, 1, 8, 1, 0, 181.275, 2313.8, 2420.9, 10.389),
(329, 523, 1, 1, 8, 1, 0, 184.868, 2316.17, 2421.01, 10.39),
(330, 598, 0, 1, 8, 1, 0, 359.478, 2251.85, 2443.42, 10.565),
(331, 599, 0, 1, 8, 2, 0, 178.946, 2269.15, 2477.16, 11.012),
(332, 599, 0, 1, 8, 2, 0, 0.401542, 2282.26, 2442.74, 11.1094),
(333, 598, 0, 1, 8, 1, 0, 180.1, 2282.5, 2477.22, 10.4775),
(334, 598, 0, 1, 8, 1, 0, 179.418, 2260.33, 2477.32, 10.565),
(335, 598, 0, 1, 8, 1, 0, 359.451, 2269.1, 2443.42, 10.566),
(336, 428, 0, 53, 8, 6, 0, 89.8853, 2313.47, 2500.36, 3.45919),
(337, 427, 0, 1, 8, 3, 0, 90.7, 2313.58, 2495.3, 3.45919),
(340, 411, 1, 1, 8, 1, 0, 89.636, 2294.22, 2451.54, 10.547),
(341, 411, 1, 1, 8, 3, 0, 90.517, 2294.3, 2468.69, 10.547),
(343, 523, 1, 1, 8, 1, 0, 180.171, 2260.41, 2459.88, 10.389),
(344, 523, 1, 1, 8, 1, 0, 181.265, 2256.73, 2459.65, 10.391),
(345, 523, 1, 1, 8, 1, 0, 180.539, 2252.04, 2459.49, 10.392),
(355, 598, 0, 1, 8, 1, 0, 180.079, 2277.64, 2459.31, 10.567),
(356, 598, 0, 1, 8, 1, 0, 179.558, 2281.81, 2459.29, 10.564),
(357, 411, 1, 1, 1, 4, 0, 91.04, 1566.03, -1633.06, 13.193),
(358, 411, 1, 1, 1, 5, 0, 90.5797, 1573.04, -1633.18, 13.1933),
(359, 598, 0, 1, 8, 1, 0, 180.798, 2256.06, 2477.27, 10.567),
(360, 598, 0, 1, 8, 1, 0, 357.382, 2260.68, 2443.31, 10.578),
(361, 497, 1, 2, 2, 4, 0, 271.137, 615.643, -553.142, 23.2092),
(362, 404, -1, -1, 0, 0, 0, 89.34, 667.657, -549.414, 16.4545),
(363, 528, 1, 1, 2, 3, 0, 268.903, 620.971, -597.003, 17.235),
(364, 596, 1, 2, 2, 4, 0, 270.711, 619.727, -542.807, 16.17),
(365, 596, 1, 2, 2, 1, 0, 271.22, 625.574, -588.809, 16.5456),
(366, 490, 0, 0, 2, 1, 0, 0.111907, 634.994, -578.595, 16.059),
(367, 490, 0, 0, 2, 1, 0, 178.41, 635.146, -562.233, 16.0572),
(368, 497, 1, 2, 2, 1, 0, 270.601, 615.729, -575.474, 25.8626),
(369, 596, 1, 2, 2, 1, 0, 91.244, 667.817, -583.078, 16.057),
(370, 596, 1, 2, 2, 1, 0, 89.039, 667.672, -586.707, 16.057),
(371, 490, 0, 0, 2, 1, 0, 359.624, 635.002, -609.293, 16.463),
(375, 596, 1, 2, 2, 1, 0, 269.211, 629.112, -534.554, 15.98),
(376, 490, 0, 0, 2, 1, 0, 359.329, 631.488, -609.281, 16.464),
(377, 470, 1, 1, 3, 4, 0, 180.464, 193.639, 1919.73, 17.6744),
(378, 470, 1, 1, 3, 4, 0, 181.074, 202.759, 1919.63, 17.5242),
(379, 470, 1, 1, 3, 4, 0, 181.501, 211.693, 1919.83, 17.525),
(380, 470, 1, 1, 3, 1, 0, 181.738, 220.739, 1920.06, 17.5246),
(381, 433, 1, 1, 3, 3, 0, 180.909, 185.418, 1928.52, 18.2175),
(382, 528, 1, 1, 3, 2, 0, 184.426, 177.403, 1929.68, 18.1377),
(383, 528, 1, 1, 3, 2, 0, 182.334, 181.037, 1929.91, 17.9978),
(384, 433, 1, 1, 3, 3, 0, 180.491, 227.692, 1928.16, 18.0773),
(385, 425, 1, 1, 3, 5, 0, 359.605, 226.018, 1887.49, 18.1905),
(386, 425, 1, 1, 3, 5, 0, 5.07395, 201.713, 1887.29, 18.2188),
(387, 598, 128, 1, 3, 1, 0, 0.090213, 212.461, 1854.53, 12.6048),
(388, 598, 128, 1, 3, 1, 0, 4.33994, 216.094, 1854.6, 12.6447),
(389, 598, 128, 1, 3, 1, 0, 3.99468, 219.372, 1854.69, 12.6479),
(390, 598, 128, 1, 3, 1, 0, 2.55421, 222.688, 1855, 12.673),
(391, 599, 128, 1, 3, 1, 0, 274.236, 205.043, 1860.26, 13.3366),
(392, 599, 128, 1, 3, 2, 0, 274.033, 204.754, 1864.24, 13.3341),
(393, 468, 128, 1, 3, 1, 0, 92.5801, 224.825, 1867.66, 12.8077),
(394, 468, 128, 1, 3, 1, 0, 91.8144, 224.91, 1866.12, 12.8081),
(395, 468, 128, 1, 3, 1, 0, 86.4821, 224.937, 1864.83, 12.8081),
(396, 468, 128, 1, 3, 1, 0, 91.7162, 225.04, 1863.4, 12.8095),
(397, 548, 1, 1, 3, 3, 0, 5.85002, 122.867, 1851.47, 19.3356),
(398, 417, 1, 1, 3, 3, 0, 358.946, 195.204, 1812.88, 17.7321),
(399, 417, 1, 1, 3, 3, 0, 2.18518, 230.038, 1812.2, 17.7304),
(400, 520, 1, 1, 3, 6, 0, 2.98401, 300.112, 1804.76, 18.3673),
(401, 520, 1, 1, 3, 6, 0, 2.06715, 314.889, 1804.37, 18.3628),
(402, 520, 1, 1, 3, 6, 0, 86.1924, 329.358, 1821.79, 18.3624),
(403, 520, 1, 1, 3, 6, 0, 89.7986, 328.924, 1835.44, 18.3636),
(405, 428, 0, 1, 1, 5, 0, 89.447, 1546.19, -1650.98, 6.014),
(406, 427, 0, 1, 1, 3, 0, 179.388, 1526.52, -1644.92, 6.022),
(408, 596, 0, 1, 1, 1, 0, 269.713, 1528.08, -1688.08, 5.614),
(409, 596, 0, 1, 1, 1, 0, 359.916, 1558.88, -1711.65, 5.612),
(410, 596, 0, 1, 1, 1, 0, 0.335, 1570.27, -1711.6, 5.612),
(411, 596, 0, 1, 1, 1, 0, 0.844, 1578.64, -1711.62, 5.61),
(412, 523, 1, 1, 1, 1, 0, 90.881, 1603.47, -1704.33, 5.459),
(413, 523, 1, 1, 1, 1, 0, 91.176, 1603.43, -1699.91, 5.461),
(414, 599, 0, 1, 1, 2, 0, 89.23, 1603.18, -1683.96, 6.08),
(415, 427, 0, 1, 1, 2, 0, 269.898, 1585.33, -1680.17, 6.029),
(416, 599, 0, 1, 1, 2, 0, 88.8076, 1600.22, -1611.23, 13.5576),
(417, 599, 0, 1, 1, 2, 0, 90.3583, 1600.36, -1606.04, 13.5725),
(418, 596, 0, 1, 1, 1, 0, 179.076, 1578.08, -1606.58, 13.1553),
(419, 596, 0, 1, 1, 1, 0, 178.991, 1573.02, -1606.51, 13.1553),
(420, 596, 0, 1, 1, 1, 0, 179.07, 1568.16, -1606.47, 13.0673),
(421, 596, 0, 1, 1, 1, 0, 179.237, 1563, -1606.4, 13.1567),
(422, 596, 0, 1, 1, 1, 0, 180.493, 1557.89, -1606.29, 13.1566),
(423, 523, 1, 1, 1, 1, 0, 272.82, 1546.83, -1604.83, 12.848),
(424, 523, 1, 1, 1, 1, 0, 271.74, 1546.84, -1606.75, 12.9577),
(425, 523, 1, 1, 1, 1, 0, 275.699, 1546.97, -1608.49, 12.9577),
(426, 523, 1, 1, 1, 1, 0, 275.699, 1546.94, -1611.29, 12.9577),
(427, 523, 6, 6, 1, 1, 0, 275.699, 1547.01, -1613.4, 12.9577),
(428, 523, 1, 1, 1, 1, 0, 275.699, 1546.88, -1615.36, 12.9577),
(430, 596, 0, 1, 1, 1, 0, 90.9599, 1547.59, -1653.13, 13.2712),
(431, 411, 1, 1, 1, 6, 0, 90.4208, 1547.65, -1669.65, 13.2434),
(432, 428, 0, 1, 1, 5, 0, 89.698, 1548.97, -1698.09, 13.734),
(433, 563, 0, 1, 1, 1, 0, 89.4746, 1563.87, -1700.79, 28.5087),
(434, 497, 0, 1, 1, 2, 0, 90.9994, 1561.9, -1651.04, 28.5224),
(435, 567, 98, 98, 4, 1, 0, 273.361, 1461.95, 2753.83, 10.7334),
(436, 560, 98, 98, 4, 1, 0, 271.655, 1460.74, 2762.53, 10.4725),
(437, 445, 98, 98, 4, 1, 0, 269.114, 1461.15, 2786.99, 10.5683),
(438, 566, 98, 98, 4, 1, 0, 269.093, 1461.35, 2794.33, 10.429),
(439, 461, 98, 98, 4, 1, 0, 269.848, 1475, 2782.96, 10.4004),
(440, 461, 98, 98, 4, 1, 0, 264.939, 1474.86, 2780.53, 10.4043),
(441, 579, 98, 98, 4, 1, 0, 179.903, 1465.46, 2838.1, 10.5793),
(442, 579, 98, 98, 4, 1, 0, 179.724, 1475.04, 2838.14, 10.8353),
(443, 405, 98, 98, 4, 1, 0, 179.379, 1484.56, 2838.49, 10.6408),
(444, 405, 98, 98, 4, 1, 0, 179.551, 1494.25, 2838.48, 10.7266),
(445, 487, 98, 98, 4, 1, 0, 144.025, 1512.29, 2841.66, 10.9628),
(446, 409, 98, 98, 4, 1, 0, 90.1389, 1529.15, 2827.29, 10.4623),
(447, 482, 98, 98, 4, 1, 0, 89.9726, 1529.39, 2818.3, 10.9863),
(448, 475, 98, 98, 4, 1, 0, 89.6317, 1529.37, 2809.18, 10.5351),
(451, 601, 1, 1, 1, 6, 0, 89.777, 1546.36, -1663.08, 5.651),
(453, 528, 79, 79, 2, 2, 0, 268.722, 620.938, -601.466, 17.236),
(454, 490, 0, 0, 2, 1, 0, 359.532, 638.439, -609.309, 16.464),
(455, 596, 1, 2, 2, 1, 0, 271.329, 625.45, -585.487, 16.5593),
(456, 560, 86, 86, 5, 1, 0, 15.8062, 2500.93, -1684.82, 13.0954),
(457, 405, 86, 86, 5, 1, 0, 26.996, 2505.16, -1683.3, 13.3182),
(458, 536, 86, 86, 5, 1, 0, 45.5014, 2508.16, -1680.93, 13.1673),
(459, 579, 86, 86, 5, 1, 0, 62.3161, 2510.63, -1676.99, 13.3455),
(460, 445, 86, 86, 5, 1, 0, 71.1699, 2512.22, -1673.01, 13.301),
(461, 492, 86, 86, 5, 1, 0, 87.901, 2512.9, -1669.03, 13.2358),
(462, 579, 86, 86, 5, 1, 0, 97.216, 2511.87, -1664.86, 13.3722),
(463, 482, 86, 86, 5, 1, 0, 98.4268, 2509.89, -1660.37, 13.6014),
(464, 409, 86, 86, 5, 1, 0, 138.808, 2505.62, -1653.62, 13.3025),
(465, 461, 86, 86, 5, 1, 0, 174.676, 2488.78, -1651.69, 13.0602),
(466, 461, 86, 86, 5, 1, 0, 177.29, 2486.17, -1651.59, 13.0466),
(467, 487, 86, 86, 5, 3, 0, 90.9702, 2530.09, -1677.62, 20.0552),
(468, 560, 6, 6, 6, 1, 0, 359.463, 703.818, -1420.77, 13.1701),
(469, 567, 6, 6, 6, 1, 0, 359.352, 713.999, -1421.14, 13.3417),
(470, 461, 6, 6, 6, 1, 0, 359.269, 714.959, -1426.93, 13.0975),
(471, 461, 6, 6, 6, 1, 0, 0.164349, 702.966, -1427.01, 13.1214),
(472, 405, 6, 6, 6, 1, 0, 0.074018, 703.648, -1437.23, 13.3154),
(473, 405, 6, 6, 6, 1, 0, 359.297, 707.573, -1437.17, 13.3154),
(474, 579, 6, 6, 6, 1, 0, 88.5199, 720.413, -1431, 13.3958),
(475, 579, 6, 6, 6, 1, 0, 89.1034, 727.153, -1431.22, 13.3935),
(476, 409, 6, 1, 6, 3, 0, 89.6926, 736.452, -1431.61, 13.2522),
(477, 482, 6, 6, 6, 1, 0, 0.306864, 745.313, -1443.34, 13.5413),
(478, 487, 6, 1, 6, 4, 0, 357.788, 704.381, -1456.88, 17.8203),
(479, 482, 85, 1, 10, 1, 0, 180.683, 1451.99, 787.362, 10.987),
(480, 445, 85, 1, 10, 1, 0, 180.665, 1445.5, 787.224, 10.6252),
(481, 566, 85, 1, 10, 1, 0, 271.052, 1413.48, 775.063, 10.5389),
(482, 405, 85, 1, 10, 1, 0, 270.11, 1413.16, 768.614, 10.6366),
(483, 567, 85, 85, 10, 1, 0, 270.832, 1413.27, 762.349, 10.626),
(484, 567, 85, 85, 10, 1, 0, 269.896, 1413.27, 755.953, 10.6276),
(485, 579, 85, 1, 10, 1, 0, 269.919, 1413.33, 748.436, 10.5907),
(486, 579, 85, 1, 10, 1, 0, 269.769, 1413.41, 743.133, 10.6778),
(487, 487, 85, 1, 10, 1, 0, 267.988, 1416.94, 730.533, 10.9642),
(488, 560, 85, 1, 10, 1, 0, 269.687, 1412.69, 717.707, 10.4695),
(489, 426, 85, 1, 10, 1, 0, 269.517, 1413.04, 711.42, 10.4787),
(490, 461, 85, 1, 10, 1, 0, 176.026, 1449.83, 731.36, 10.4066),
(491, 461, 85, 1, 10, 1, 0, 181.924, 1453.92, 731.397, 10.4038),
(492, 409, 85, 1, 10, 1, 0, 91.8317, 1496.33, 732.785, 10.589),
(493, 464, -1, -1, 0, 0, 0, 51.6, 1972.36, -2177.1, 16.6885),
(494, 465, -1, -1, 0, 0, 0, -56.94, 1950.97, -2177.2, 16.8155),
(495, 441, -1, -1, 0, 0, 0, -133.68, 326.681, -1538.65, 32.1894),
(496, 441, -1, -1, 0, 0, 0, -133.8, 330.888, -1533.08, 32.1894),
(497, 564, -1, -1, 0, 4, 0, 89.9999, 1546.96, -1672.41, 14.0163),
(498, 564, -1, -1, 0, 0, 0, 89.9999, 1547.01, -1678.78, 14.0163),
(499, 444, -1, -1, 0, 0, 0, 26.8521, -1887.4, -1175.49, 37.4482),
(500, 487, 175, 175, 11, 3, 0, 356.122, 1042.13, -351.372, 74.2103),
(501, 411, 1, 1, 1, 3, 0, 90.2806, 1559.61, -1633.2, 13.1909),
(517, 487, -1, -1, 0, 0, 0, 97.8022, 2204.31, 1676.3, 20.5495);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `warlogs`
--

CREATE TABLE `warlogs` (
  `id` int(11) NOT NULL,
  `PlayerID` int(11) NOT NULL,
  `WarID` int(11) NOT NULL,
  `Kills` int(11) NOT NULL,
  `Deaths` int(11) NOT NULL,
  `Faction` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `wars`
--

CREATE TABLE `wars` (
  `id` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Attacker` int(11) NOT NULL,
  `Defender` int(11) NOT NULL,
  `Atscore` int(11) NOT NULL,
  `Defscore` int(11) NOT NULL,
  `Result` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `actiunipanelbre`
--
ALTER TABLE `actiunipanelbre`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `adv`
--
ALTER TABLE `adv`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `answers_app`
--
ALTER TABLE `answers_app`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `antifraudaraport`
--
ALTER TABLE `antifraudaraport`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `aplications`
--
ALTER TABLE `aplications`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `atms`
--
ALTER TABLE `atms`
  ADD PRIMARY KEY (`atmId`);

--
-- Indexuri pentru tabele `bizz`
--
ALTER TABLE `bizz`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `blockedaccounts`
--
ALTER TABLE `blockedaccounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `changemail`
--
ALTER TABLE `changemail`
  ADD PRIMARY KEY (`ChangeMailKey`);

--
-- Indexuri pentru tabele `chat_logs`
--
ALTER TABLE `chat_logs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `clancars`
--
ALTER TABLE `clancars`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `clans`
--
ALTER TABLE `clans`
  ADD PRIMARY KEY (`clanID`);

--
-- Indexuri pentru tabele `clan_logs`
--
ALTER TABLE `clan_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `donatiibre`
--
ALTER TABLE `donatiibre`
  ADD PRIMARY KEY (`donateID`);

--
-- Indexuri pentru tabele `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`donateID`);

--
-- Indexuri pentru tabele `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `eventobjects`
--
ALTER TABLE `eventobjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `factionlog`
--
ALTER TABLE `factionlog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `factions`
--
ALTER TABLE `factions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `faction_questions`
--
ALTER TABLE `faction_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `frequencies`
--
ALTER TABLE `frequencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `garages`
--
ALTER TABLE `garages`
  ADD PRIMARY KEY (`Owner`);

--
-- Indexuri pentru tabele `giftbox_logs`
--
ALTER TABLE `giftbox_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `kicklogs`
--
ALTER TABLE `kicklogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `lastfreports`
--
ALTER TABLE `lastfreports`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `log_admin`
--
ALTER TABLE `log_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `namechanges`
--
ALTER TABLE `namechanges`
  ADD PRIMARY KEY (`namechangeid`);

--
-- Indexuri pentru tabele `newbie_logs`
--
ALTER TABLE `newbie_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `objects_accesory`
--
ALTER TABLE `objects_accesory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `olderfreports`
--
ALTER TABLE `olderfreports`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `panelactions`
--
ALTER TABLE `panelactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `panelactions2`
--
ALTER TABLE `panelactions2`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `panel_chat`
--
ALTER TABLE `panel_chat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `panel_restrict`
--
ALTER TABLE `panel_restrict`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `playerconnections`
--
ALTER TABLE `playerconnections`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `playerlogs`
--
ALTER TABLE `playerlogs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `player_accessory`
--
ALTER TABLE `player_accessory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `punishlogs`
--
ALTER TABLE `punishlogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `recover`
--
ALTER TABLE `recover`
  ADD PRIMARY KEY (`RecoverKey`);

--
-- Indexuri pentru tabele `reply_complaints`
--
ALTER TABLE `reply_complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `reply_requests`
--
ALTER TABLE `reply_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `reply_tickets`
--
ALTER TABLE `reply_tickets`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexuri pentru tabele `report_logs`
--
ALTER TABLE `report_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `session_data`
--
ALTER TABLE `session_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `shop_logs`
--
ALTER TABLE `shop_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `staff_logs`
--
ALTER TABLE `staff_logs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `su_logs`
--
ALTER TABLE `su_logs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `svars`
--
ALTER TABLE `svars`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `timeonline`
--
ALTER TABLE `timeonline`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `timeplayed`
--
ALTER TABLE `timeplayed`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `toph`
--
ALTER TABLE `toph`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `turfs`
--
ALTER TABLE `turfs`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `unban_requests`
--
ALTER TABLE `unban_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `warlogs`
--
ALTER TABLE `warlogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexuri pentru tabele `wars`
--
ALTER TABLE `wars`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `actiunipanelbre`
--
ALTER TABLE `actiunipanelbre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `adv`
--
ALTER TABLE `adv`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pentru tabele `answers_app`
--
ALTER TABLE `answers_app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `antifraudaraport`
--
ALTER TABLE `antifraudaraport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `aplications`
--
ALTER TABLE `aplications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `atms`
--
ALTER TABLE `atms`
  MODIFY `atmId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT pentru tabele `bizz`
--
ALTER TABLE `bizz`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT pentru tabele `blockedaccounts`
--
ALTER TABLE `blockedaccounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `cars`
--
ALTER TABLE `cars`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `chat_logs`
--
ALTER TABLE `chat_logs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `clancars`
--
ALTER TABLE `clancars`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `clans`
--
ALTER TABLE `clans`
  MODIFY `clanID` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `clan_logs`
--
ALTER TABLE `clan_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `donatiibre`
--
ALTER TABLE `donatiibre`
  MODIFY `donateID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `donations`
--
ALTER TABLE `donations`
  MODIFY `donateID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `emails`
--
ALTER TABLE `emails`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `eventobjects`
--
ALTER TABLE `eventobjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT pentru tabele `factionlog`
--
ALTER TABLE `factionlog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `factions`
--
ALTER TABLE `factions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pentru tabele `faction_questions`
--
ALTER TABLE `faction_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;

--
-- AUTO_INCREMENT pentru tabele `frequencies`
--
ALTER TABLE `frequencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `friends`
--
ALTER TABLE `friends`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `giftbox_logs`
--
ALTER TABLE `giftbox_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `houses`
--
ALTER TABLE `houses`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT pentru tabele `kicklogs`
--
ALTER TABLE `kicklogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `lastfreports`
--
ALTER TABLE `lastfreports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `log_admin`
--
ALTER TABLE `log_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `namechanges`
--
ALTER TABLE `namechanges`
  MODIFY `namechangeid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `newbie_logs`
--
ALTER TABLE `newbie_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `objects_accesory`
--
ALTER TABLE `objects_accesory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT pentru tabele `olderfreports`
--
ALTER TABLE `olderfreports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `panelactions`
--
ALTER TABLE `panelactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `panelactions2`
--
ALTER TABLE `panelactions2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `panel_chat`
--
ALTER TABLE `panel_chat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `panel_restrict`
--
ALTER TABLE `panel_restrict`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `playerconnections`
--
ALTER TABLE `playerconnections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `playerlogs`
--
ALTER TABLE `playerlogs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `player_accessory`
--
ALTER TABLE `player_accessory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `punishlogs`
--
ALTER TABLE `punishlogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `reply_complaints`
--
ALTER TABLE `reply_complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `reply_requests`
--
ALTER TABLE `reply_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `reply_tickets`
--
ALTER TABLE `reply_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `report_logs`
--
ALTER TABLE `report_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `session_data`
--
ALTER TABLE `session_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `shop_logs`
--
ALTER TABLE `shop_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `staff_logs`
--
ALTER TABLE `staff_logs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `stock`
--
ALTER TABLE `stock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT pentru tabele `su_logs`
--
ALTER TABLE `su_logs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `svars`
--
ALTER TABLE `svars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pentru tabele `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `timeonline`
--
ALTER TABLE `timeonline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `timeplayed`
--
ALTER TABLE `timeplayed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `toph`
--
ALTER TABLE `toph`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `turfs`
--
ALTER TABLE `turfs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pentru tabele `unban_requests`
--
ALTER TABLE `unban_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=519;

--
-- AUTO_INCREMENT pentru tabele `warlogs`
--
ALTER TABLE `warlogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pentru tabele `wars`
--
ALTER TABLE `wars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
